% Specify the folders and filenames



% Construct the full paths to the .mat files
filePath11 = load(fullfile('ROUTINE_VAC_SCENARIO_1_DRC', 'age_specific_cases1.mat'));
filePath12 = load(fullfile('SCENARIO_0_ROUTINE_VAC_DRC', 'age_specific_cases2.mat'));
filePath13 = load(fullfile('SCENARIO_0_ROUTINE_VAC_DRC', 'age_specific_cases3.mat'));
filePath14 = load(fullfile('SCENARIO_0_ROUTINE_VAC_DRC', 'age_specific_cases4.mat'));
filePath15 = load(fullfile('SCENARIO_0_ROUTINE_VAC_DRC', 'age_specific_cases5.mat'));
filePath16 = load(fullfile('SCENARIO_0_ROUTINE_VAC_DRC', 'age_specific_cases6.mat'));
filePath17 = load(fullfile('SCENARIO_0_ROUTINE_VAC_DRC', 'age_specific_cases7.mat'));
filePath18 = load(fullfile('SCENARIO_0_ROUTINE_VAC_DRC', 'age_specific_cases8.mat'));
filePath19 = load(fullfile('SCENARIO_0_ROUTINE_VAC_DRC', 'age_specific_cases9.mat'));
filePath110 = load(fullfile('SCENARIO_0_ROUTINE_VAC_DRC', 'age_specific_cases10.mat'));
filePath111 = load(fullfile('SCENARIO_0_ROUTINE_VAC_DRC', 'age_specific_cases_all.mat'));


filePath21 = load(fullfile('EARLY_VAC_SCENARIO_1_DRC', 'age_specific_cases1.mat'));
filePath22 = load(fullfile('EARLY_VAC_SCENARIO_1_DRC', 'age_specific_cases2.mat'));
filePath23 = load(fullfile('EARLY_VAC_SCENARIO_1_DRC', 'age_specific_cases3.mat'));
filePath24 = load(fullfile('EARLY_VAC_SCENARIO_1_DRC', 'age_specific_cases4.mat'));
filePath25 = load(fullfile('EARLY_VAC_SCENARIO_1_DRC', 'age_specific_cases5.mat'));
filePath26 = load(fullfile('EARLY_VAC_SCENARIO_1_DRC', 'age_specific_cases6.mat'));
filePath27 = load(fullfile('EARLY_VAC_SCENARIO_1_DRC', 'age_specific_cases7.mat'));
filePath28 = load(fullfile('EARLY_VAC_SCENARIO_1_DRC', 'age_specific_cases8.mat'));
filePath29 = load(fullfile('EARLY_VAC_SCENARIO_1_DRC', 'age_specific_cases9.mat'));
filePath210 = load(fullfile('EARLY_VAC_SCENARIO_1_DRC', 'age_specific_cases10.mat'));
filePath211 = load(fullfile('EARLY_VAC_SCENARIO_1_DRC', 'age_specific_cases_all.mat'));



% Access variables within the .mat files (assuming variables are named)
  var11 = filePath11.curvesforecasts_age_specific1; 
  var12 = filePath12.curvesforecasts_age_specific2; 
  var13 = filePath13.curvesforecasts_age_specific3;
  var14 = filePath14.curvesforecasts_age_specific4;
  var15 = filePath15.curvesforecasts_age_specific5;
  var16 = filePath16.curvesforecasts_age_specific6;
  var17 = filePath17.curvesforecasts_age_specific7;
  var18 = filePath18.curvesforecasts_age_specific8;
  var19 = filePath19.curvesforecasts_age_specific9;
  var110 = filePath110.curvesforecasts_age_specific10;


   avar11 = mean(var11,2); 
  avar12 = mean(var12,2); 
  avar13 = mean(var13,2);
  avar14 = mean(var14,2);
  avar15 = mean(var15,2);
  avar16 = mean(var16,2);
  avar17 = mean(var17,2);
  avar18 =mean(var18,2);
  avar19 = mean(var19,2);
  avar110 = mean(var110,2);
  var111 = filePath111.curvesforecasts1;
  var112 = filePath211.curvesforecasts1;


  var21 = filePath21.curvesforecasts_age_specific1; 
  var22 = filePath22.curvesforecasts_age_specific2; 
  var23 = filePath23.curvesforecasts_age_specific3;
  var24 = filePath24.curvesforecasts_age_specific4;
  var25 = filePath25.curvesforecasts_age_specific5;
  var26 = filePath26.curvesforecasts_age_specific6;
  var27 = filePath27.curvesforecasts_age_specific7;
  var28 = filePath28.curvesforecasts_age_specific8;
  var29 = filePath29.curvesforecasts_age_specific9;
  var210 = filePath210.curvesforecasts_age_specific10;


  avar21 = mean(var21,2); 
  avar22 = mean(var22,2); 
  avar23 = mean(var23,2);
  avar24 = mean(var24,2);
  avar25 = mean(var25,2);
  avar26 = mean(var26,2);
  avar27 = mean(var27,2);
  avar28 =mean(var28,2);
  avar29 = mean(var29,2);
  avar210 = mean(var210,2);
  %var211 = filePath211.curvesforecasts1;
  
%averted_1=zeros(1,1000);

  
    % averted_1(j)=(sum(var13(25:end,j))-sum(var23(25:end,j)))./sum(var13(25:end,j));
    % averted_1=((sum(avar13(25:end))-sum(avar23(25:end)))/sum(avar13(25:end)))*100000;
averted_1=((avar13-avar23)./avar13)*10000;
% averted_1=(avar13-avar23);
    averted_1

  %%%%%%%%%%%%%%%%%%%%%
  %plot(averted_1)


  %%%%%%%%%%%%%%%%%%%%%%%%%
  %%%%%%%%%%%%%%%%%%%%%%%%
  %SCENARIO-2
  %%%%%%%%%%%%%%%%%%%%%%%%%
  %%%%%%%%%%%%%%%%%%%%%%%

filePath11 = load(fullfile('ROUTINE_VAC_SCENARIO_2_DRC', 'age_specific_cases1.mat'));
filePath12 = load(fullfile('ROUTINE_VAC_SCENARIO_2_DRC', 'age_specific_cases2.mat'));
filePath13 = load(fullfile('ROUTINE_VAC_SCENARIO_2_DRC', 'age_specific_cases3.mat'));
filePath14 = load(fullfile('ROUTINE_VAC_SCENARIO_2_DRC', 'age_specific_cases4.mat'));
filePath15 = load(fullfile('ROUTINE_VAC_SCENARIO_2_DRC', 'age_specific_cases5.mat'));
filePath16 = load(fullfile('ROUTINE_VAC_SCENARIO_2_DRC', 'age_specific_cases6.mat'));
filePath17 = load(fullfile('ROUTINE_VAC_SCENARIO_2_DRC', 'age_specific_cases7.mat'));
filePath18 = load(fullfile('ROUTINE_VAC_SCENARIO_2_DRC', 'age_specific_cases8.mat'));
filePath19 = load(fullfile('ROUTINE_VAC_SCENARIO_2_DRC', 'age_specific_cases9.mat'));
filePath110 = load(fullfile('ROUTINE_VAC_SCENARIO_2_DRC', 'age_specific_cases10.mat'));
filePath111 = load(fullfile('ROUTINE_VAC_SCENARIO_2_DRC', 'age_specific_cases_all.mat'));


filePath21 = load(fullfile('EARLY_VAC_SCENARIO_2_DRC', 'age_specific_cases1.mat'));
filePath22 = load(fullfile('EARLY_VAC_SCENARIO_2_DRC', 'age_specific_cases2.mat'));
filePath23 = load(fullfile('EARLY_VAC_SCENARIO_2_DRC', 'age_specific_cases3.mat'));
filePath24 = load(fullfile('EARLY_VAC_SCENARIO_2_DRC', 'age_specific_cases4.mat'));
filePath25 = load(fullfile('EARLY_VAC_SCENARIO_2_DRC', 'age_specific_cases5.mat'));
filePath26 = load(fullfile('EARLY_VAC_SCENARIO_2_DRC', 'age_specific_cases6.mat'));
filePath27 = load(fullfile('EARLY_VAC_SCENARIO_2_DRC', 'age_specific_cases7.mat'));
filePath28 = load(fullfile('EARLY_VAC_SCENARIO_2_DRC', 'age_specific_cases8.mat'));
filePath29 = load(fullfile('EARLY_VAC_SCENARIO_2_DRC', 'age_specific_cases9.mat'));
filePath210 = load(fullfile('EARLY_VAC_SCENARIO_2_DRC', 'age_specific_cases10.mat'));
filePath211 = load(fullfile('EARLY_VAC_SCENARIO_2_DRC', 'age_specific_cases_all.mat'));



% Access variables within the .mat files (assuming variables are named)
  var11 = filePath11.curvesforecasts_age_specific1; 
  var12 = filePath12.curvesforecasts_age_specific2; 
  var13 = filePath13.curvesforecasts_age_specific3;
  var14 = filePath14.curvesforecasts_age_specific4;
  var15 = filePath15.curvesforecasts_age_specific5;
  var16 = filePath16.curvesforecasts_age_specific6;
  var17 = filePath17.curvesforecasts_age_specific7;
  var18 = filePath18.curvesforecasts_age_specific8;
  var19 = filePath19.curvesforecasts_age_specific9;
  var110 = filePath110.curvesforecasts_age_specific10;

   avar11 = mean(var11,2); 
  avar12 = mean(var12,2); 
  avar13 = mean(var13,2);
  avar14 = mean(var14,2);
  avar15 = mean(var15,2);
  avar16 = mean(var16,2);
  avar17 = mean(var17,2);
  avar18 =mean(var18,2);
  avar19 = mean(var19,2);
  avar110 = mean(var110,2);
  %var111 = filePath111.curvesforecasts1;


  var21 = filePath21.curvesforecasts_age_specific1; 
  var22 = filePath22.curvesforecasts_age_specific2; 
  var23 = filePath23.curvesforecasts_age_specific3;
  var24 = filePath24.curvesforecasts_age_specific4;
  var25 = filePath25.curvesforecasts_age_specific5;
  var26 = filePath26.curvesforecasts_age_specific6;
  var27 = filePath27.curvesforecasts_age_specific7;
  var28 = filePath28.curvesforecasts_age_specific8;
  var29 = filePath29.curvesforecasts_age_specific9;
  var210 = filePath210.curvesforecasts_age_specific10;


  avar21 = mean(var21,2); 
  avar22 = mean(var22,2); 
  avar23 = mean(var23,2);
  avar24 = mean(var24,2);
  avar25 = mean(var25,2);
  avar26 = mean(var26,2);
  avar27 = mean(var27,2);
  avar28 =mean(var28,2);
  avar29 = mean(var29,2);
  avar210 = mean(var210,2);
  %var211 = filePath211.curvesforecasts1;
  
%averted_1=zeros(1,1000);

  
    % averted_1(j)=(sum(var13(25:end,j))-sum(var23(25:end,j)))./sum(var13(25:end,j));
    % averted_2=((sum(avar13(25:end))-sum(avar23(25:end)))/sum(avar13(25:end)))*100000;
 averted_2=((avar13-avar23)./avar13)*10000;
Raverted_2=(avar13-avar23);
    averted_2


     %%%%%%%%%%%%%%%%%%%%%%%%%
  %%%%%%%%%%%%%%%%%%%%%%%%
  %SCENARIO-2
  %%%%%%%%%%%%%%%%%%%%%%%%%
  %%%%%%%%%%%%%%%%%%%%%%%

filePath11 = load(fullfile('ROUTINE_VAC_SCENARIO_3_DRC', 'age_specific_cases1.mat'));
filePath12 = load(fullfile('ROUTINE_VAC_SCENARIO_3_DRC', 'age_specific_cases2.mat'));
filePath13 = load(fullfile('ROUTINE_VAC_SCENARIO_3_DRC', 'age_specific_cases3.mat'));
filePath14 = load(fullfile('ROUTINE_VAC_SCENARIO_3_DRC', 'age_specific_cases4.mat'));
filePath15 = load(fullfile('ROUTINE_VAC_SCENARIO_3_DRC', 'age_specific_cases5.mat'));
filePath16 = load(fullfile('ROUTINE_VAC_SCENARIO_3_DRC', 'age_specific_cases6.mat'));
filePath17 = load(fullfile('ROUTINE_VAC_SCENARIO_3_DRC', 'age_specific_cases7.mat'));
filePath18 = load(fullfile('ROUTINE_VAC_SCENARIO_3_DRC', 'age_specific_cases8.mat'));
filePath19 = load(fullfile('ROUTINE_VAC_SCENARIO_3_DRC', 'age_specific_cases9.mat'));
filePath110 = load(fullfile('ROUTINE_VAC_SCENARIO_3_DRC', 'age_specific_cases10.mat'));
filePath111 = load(fullfile('ROUTINE_VAC_SCENARIO_3_DRC', 'age_specific_cases_all.mat'));


filePath21 = load(fullfile('EARLY_VAC_SCENARIO_3_DRC', 'age_specific_cases1.mat'));
filePath22 = load(fullfile('EARLY_VAC_SCENARIO_3_DRC', 'age_specific_cases2.mat'));
filePath23 = load(fullfile('EARLY_VAC_SCENARIO_3_DRC', 'age_specific_cases3.mat'));
filePath24 = load(fullfile('EARLY_VAC_SCENARIO_3_DRC', 'age_specific_cases4.mat'));
filePath25 = load(fullfile('EARLY_VAC_SCENARIO_3_DRC', 'age_specific_cases5.mat'));
filePath26 = load(fullfile('EARLY_VAC_SCENARIO_3_DRC', 'age_specific_cases6.mat'));
filePath27 = load(fullfile('EARLY_VAC_SCENARIO_3_DRC', 'age_specific_cases7.mat'));
filePath28 = load(fullfile('EARLY_VAC_SCENARIO_3_DRC', 'age_specific_cases8.mat'));
filePath29 = load(fullfile('EARLY_VAC_SCENARIO_3_DRC', 'age_specific_cases9.mat'));
filePath210 = load(fullfile('EARLY_VAC_SCENARIO_3_DRC', 'age_specific_cases10.mat'));
filePath211 = load(fullfile('EARLY_VAC_SCENARIO_3_DRC', 'age_specific_cases_all.mat'));



% Access variables within the .mat files (assuming variables are named)
  var11 = filePath11.curvesforecasts_age_specific1; 
  var12 = filePath12.curvesforecasts_age_specific2; 
  var13 = filePath13.curvesforecasts_age_specific3;
  var14 = filePath14.curvesforecasts_age_specific4;
  var15 = filePath15.curvesforecasts_age_specific5;
  var16 = filePath16.curvesforecasts_age_specific6;
  var17 = filePath17.curvesforecasts_age_specific7;
  var18 = filePath18.curvesforecasts_age_specific8;
  var19 = filePath19.curvesforecasts_age_specific9;
  var110 = filePath110.curvesforecasts_age_specific10;

   avar11 = mean(var11,2); 
  avar12 = mean(var12,2); 
  avar13 = mean(var13,2);
  avar14 = mean(var14,2);
  avar15 = mean(var15,2);
  avar16 = mean(var16,2);
  avar17 = mean(var17,2);
  avar18 =mean(var18,2);
  avar19 = mean(var19,2);
  avar110 = mean(var110,2);
  %var111 = filePath111.curvesforecasts1;


  var21 = filePath21.curvesforecasts_age_specific1; 
  var22 = filePath22.curvesforecasts_age_specific2; 
  var23 = filePath23.curvesforecasts_age_specific3;
  var24 = filePath24.curvesforecasts_age_specific4;
  var25 = filePath25.curvesforecasts_age_specific5;
  var26 = filePath26.curvesforecasts_age_specific6;
  var27 = filePath27.curvesforecasts_age_specific7;
  var28 = filePath28.curvesforecasts_age_specific8;
  var29 = filePath29.curvesforecasts_age_specific9;
  var210 = filePath210.curvesforecasts_age_specific10;


  avar21 = mean(var21,2); 
  avar22 = mean(var22,2); 
  avar23 = mean(var23,2);
  avar24 = mean(var24,2);
  avar25 = mean(var25,2);
  avar26 = mean(var26,2);
  avar27 = mean(var27,2);
  avar28 =mean(var28,2);
  avar29 = mean(var29,2);
  avar210 = mean(var210,2);
  %var211 = filePath211.curvesforecasts1;
  
%averted_1=zeros(1,1000);

  
    % averted_1(j)=(sum(var13(25:end,j))-sum(var23(25:end,j)))./sum(var13(25:end,j));
    %averted_3=((sum(avar13(25:end))-sum(avar23(25:end)))/sum(avar13(25:end)))*100000;
averted_3=((avar13-avar23)./avar13)*10000;
% averted_3=(avar13-avar23);
    averted_3


     %%%%%%%%%%%%%%%%%%%%%%%%%
  %%%%%%%%%%%%%%%%%%%%%%%%
  %SCENARIO-2
  %%%%%%%%%%%%%%%%%%%%%%%%%
  %%%%%%%%%%%%%%%%%%%%%%%

filePath11 = load(fullfile('ROUTINE_VAC_SCENARIO_4_DRC', 'age_specific_cases1.mat'));
filePath12 = load(fullfile('ROUTINE_VAC_SCENARIO_4_DRC', 'age_specific_cases2.mat'));
filePath13 = load(fullfile('ROUTINE_VAC_SCENARIO_4_DRC', 'age_specific_cases3.mat'));
filePath14 = load(fullfile('ROUTINE_VAC_SCENARIO_4_DRC', 'age_specific_cases4.mat'));
filePath15 = load(fullfile('ROUTINE_VAC_SCENARIO_4_DRC', 'age_specific_cases5.mat'));
filePath16 = load(fullfile('ROUTINE_VAC_SCENARIO_4_DRC', 'age_specific_cases6.mat'));
filePath17 = load(fullfile('ROUTINE_VAC_SCENARIO_4_DRC', 'age_specific_cases7.mat'));
filePath18 = load(fullfile('ROUTINE_VAC_SCENARIO_4_DRC', 'age_specific_cases8.mat'));
filePath19 = load(fullfile('ROUTINE_VAC_SCENARIO_4_DRC', 'age_specific_cases9.mat'));
filePath110 = load(fullfile('ROUTINE_VAC_SCENARIO_4_DRC', 'age_specific_cases10.mat'));
filePath111 = load(fullfile('ROUTINE_VAC_SCENARIO_4_DRC', 'age_specific_cases_all.mat'));


filePath21 = load(fullfile('EARLY_VAC_SCENARIO_4_DRC', 'age_specific_cases1.mat'));
filePath22 = load(fullfile('EARLY_VAC_SCENARIO_4_DRC', 'age_specific_cases2.mat'));
filePath23 = load(fullfile('EARLY_VAC_SCENARIO_4_DRC', 'age_specific_cases3.mat'));
filePath24 = load(fullfile('EARLY_VAC_SCENARIO_4_DRC', 'age_specific_cases4.mat'));
filePath25 = load(fullfile('EARLY_VAC_SCENARIO_4_DRC', 'age_specific_cases5.mat'));
filePath26 = load(fullfile('EARLY_VAC_SCENARIO_4_DRC', 'age_specific_cases6.mat'));
filePath27 = load(fullfile('EARLY_VAC_SCENARIO_4_DRC', 'age_specific_cases7.mat'));
filePath28 = load(fullfile('EARLY_VAC_SCENARIO_4_DRC', 'age_specific_cases8.mat'));
filePath29 = load(fullfile('EARLY_VAC_SCENARIO_4_DRC', 'age_specific_cases9.mat'));
filePath210 = load(fullfile('EARLY_VAC_SCENARIO_4_DRC', 'age_specific_cases10.mat'));
filePath211 = load(fullfile('EARLY_VAC_SCENARIO_4_DRC', 'age_specific_cases_all.mat'));



% Access variables within the .mat files (assuming variables are named)
  var11 = filePath11.curvesforecasts_age_specific1; 
  var12 = filePath12.curvesforecasts_age_specific2; 
  var13 = filePath13.curvesforecasts_age_specific3;
  var14 = filePath14.curvesforecasts_age_specific4;
  var15 = filePath15.curvesforecasts_age_specific5;
  var16 = filePath16.curvesforecasts_age_specific6;
  var17 = filePath17.curvesforecasts_age_specific7;
  var18 = filePath18.curvesforecasts_age_specific8;
  var19 = filePath19.curvesforecasts_age_specific9;
  var110 = filePath110.curvesforecasts_age_specific10;

   avar11 = mean(var11,2); 
  avar12 = mean(var12,2); 
  avar13 = mean(var13,2);
  avar14 = mean(var14,2);
  avar15 = mean(var15,2);
  avar16 = mean(var16,2);
  avar17 = mean(var17,2);
  avar18 =mean(var18,2);
  avar19 = mean(var19,2);
  avar110 = mean(var110,2);
  %var111 = filePath111.curvesforecasts1;


  var21 = filePath21.curvesforecasts_age_specific1; 
  var22 = filePath22.curvesforecasts_age_specific2; 
  var23 = filePath23.curvesforecasts_age_specific3;
  var24 = filePath24.curvesforecasts_age_specific4;
  var25 = filePath25.curvesforecasts_age_specific5;
  var26 = filePath26.curvesforecasts_age_specific6;
  var27 = filePath27.curvesforecasts_age_specific7;
  var28 = filePath28.curvesforecasts_age_specific8;
  var29 = filePath29.curvesforecasts_age_specific9;
  var210 = filePath210.curvesforecasts_age_specific10;


  avar21 = mean(var21,2); 
  avar22 = mean(var22,2); 
  avar23 = mean(var23,2);
  avar24 = mean(var24,2);
  avar25 = mean(var25,2);
  avar26 = mean(var26,2);
  avar27 = mean(var27,2);
  avar28 =mean(var28,2);
  avar29 = mean(var29,2);
  avar210 = mean(var210,2);
  %var211 = filePath211.curvesforecasts1;
  
%averted_1=zeros(1,1000);

  
    % averted_1(j)=(sum(var13(25:end,j))-sum(var23(25:end,j)))./sum(var13(25:end,j));
    % averted_4=((sum(avar13(25:end))-sum(avar23(25:end)))/sum(avar13(25:end)))*100000;
averted_4=((avar13-avar23)./avar13)*10000;
% averted_4=(avar13-avar23);

    averted_4

    averted_all=[sum(averted_1(25:end)), sum(averted_4(25:end)), sum(averted_3(25:end)), sum(averted_2(25:end))];

    bar(averted_all);
%length(averted_1(25:end))

xticks(1:2:27); 
xticklabels({'2024', '2026', '2028', '2030', '2032', '2034', '2036', ...
    '2038', '2040', '2042', '2044', '2046','2048','2050'});
% ylim([0,5500]);
xlabel('\fontsize{12}Time (years)');
ylabel('\fontsize{12}Averted cases per 10000 infected')