clear all
close all
clc

load curves.mat
load Phatss.mat

data1=[1678 2152 2788 3712 3524 146 126 84 2 1 4 315 260 124 71.00 1359.00 ...
277 958 28 66.00 37.00 160.00 6718.00 385.00];
DT=1; % temporal resolution of the data in days

% create time vector in days
timevect=1:length(data1);

% number of bootstrap realizations
M=1000;
% estimate mean and 95% CI from distribution of parameter estimates
param_alpha111=[mean(Phatss(:,1)) quantile(Phatss(:,1),0.025) quantile(Phatss(:,1),0.975)];
param_alpha112=[mean(Phatss(:,2)) quantile(Phatss(:,2),0.025) quantile(Phatss(:,2),0.975)];
param_alpha113=[mean(Phatss(:,3)) quantile(Phatss(:,3),0.025) quantile(Phatss(:,3),0.975)];
param_alpha114=[mean(Phatss(:,4)) quantile(Phatss(:,4),0.025) quantile(Phatss(:,4),0.975)];
param_reporting=[mean(Phatss(:,5)) quantile(Phatss(:,5),0.025) quantile(Phatss(:,5),0.975)];

cad1=strcat('alpha_111=',num2str(param_alpha111(end,1),2),' (95% CI:',num2str(param_alpha111(end,2),2),',',num2str(param_alpha111(end,3),2),')')
cad2=strcat('alpha_112=',num2str(param_alpha112(end,1),2),' (95% CI:',num2str(param_alpha112(end,2),2),',',num2str(param_alpha112(end,3),2),')')
cad3=strcat('alpha_113=',num2str(param_alpha113(end,1),2),' (95% CI:',num2str(param_alpha113(end,2),2),',',num2str(param_alpha113(end,3),2),')')
cad4=strcat('alpha_114=',num2str(param_alpha114(end,1),2),' (95% CI:',num2str(param_alpha114(end,2),2),',',num2str(param_alpha114(end,3),2),')')
cad5=strcat('reporting=',num2str(param_reporting(end,1),2),' (95% CI:',num2str(param_reporting(end,2),2),',',num2str(param_reporting(end,3),2),')')
% plot empirical distributions of r and p
% figure(1)
% subplot(2,3,1)
% hist(Phatss(:,1))
% xlabel('alpha_111')
% ylabel('Frequency')
% 
% % title(cad1)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,2)
% hist(Phatss(:,2))
% xlabel('alpha_112')
% ylabel('Frequency')
% 
% % title(cad2)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,3)
% hist(Phatss(:,3))
% xlabel('alpha_113')
% ylabel('Frequency')
% 
% % title(cad3)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,4)
% hist(Phatss(:,4))
% xlabel('alpha_114')
% ylabel('Frequency')
% 
% % title(cad4)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,3)
% hist(Phatss(:,3))
% xlabel('alpha_113')
% ylabel('Frequency')
% 
% % title(cad3)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,5)
% hist(Phatss(:,5))
% xlabel('reporting rate')
% ylabel('Frequency')
% 
% % title(cad4)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')

% plot model fit and uncertainty around model fit

% param_beta_e_time2=[];
% param_beta_h_time2=[];
% param_rho_time2=[];
% param_nu_time2=[];

%% 3) Generate short-term forecasts

close all

% forecast horizon
forecastingperiod=27; % number of data points ahead

timevect2=(1:forecastingperiod);

% vector to store forecast curves
curvesforecasts1=[]; curvesforecasts_age_specific1=[];
curvesforecasts_age_specific2=[];curvesforecasts_age_specific3=[];
curvesforecasts_age_specific4=[];curvesforecasts_age_specific5=[];
curvesforecasts_age_specific6=[];curvesforecasts_age_specific7=[];
curvesforecasts_age_specific8=[];curvesforecasts_age_specific9=[];
curvesforecasts_age_specific10=[];

% generate forecast curves from each bootstrap realization
for realization=1:M
    
%     r_hat=Phatss(realization,1);
%     p_hat=Phatss(realization,2);
    z1=Phatss(realization,:); 
%     [~,x]=ode45(@simpleGrowth,timevect2,IC,[],r_hat,p_hat,flag1);     
    
     incidence11=measles_sol1_susceptible(z1, timevect, timevect2);
    %incidence1=incidence11(:,1);
    
    %NNN=incidence11(:,end);
    age_specific_susceptible=incidence11;
    
    % curvesforecasts1=[curvesforecasts1 incidence1];
    curvesforecasts_age_specific1=[curvesforecasts_age_specific1 age_specific_susceptible(:,1)];
    curvesforecasts_age_specific2=[curvesforecasts_age_specific2 age_specific_susceptible(:,2)];
    curvesforecasts_age_specific3=[curvesforecasts_age_specific3 age_specific_susceptible(:,3)];
    %curvesforecasts_age_specific4=[curvesforecasts_age_specific4 age_specific_susceptible(:,4)];
    % curvesforecasts_age_specific5=[curvesforecasts_age_specific5 age_specific_susceptible(:,5)];
    % curvesforecasts_age_specific6=[curvesforecasts_age_specific6 age_specific_susceptible(:,6)];
    % curvesforecasts_age_specific7=[curvesforecasts_age_specific7 age_specific_susceptible(:,7)];
    % curvesforecasts_age_specific8=[curvesforecasts_age_specific8 age_specific_susceptible(:,8)];
    % curvesforecasts_age_specific9=[curvesforecasts_age_specific9 age_specific_susceptible(:,9)];
    % curvesforecasts_age_specific10=[curvesforecasts_age_specific10 age_specific_susceptible(:,10)];
    
end

 plot(age_specific_susceptible(1:24*26,:));

% plot forecast curves
% figure(2)
% plot(timevect, curvesforecasts_age_specific5(1:length(timevect),:),'c-')
% hold on
% curves_fitting =  curvesforecasts_age_specific5(1:length(timevect),:);
% %line1=plot(timevect,mean(curves,2),'r-')
% line1=plot(timevect,quantile(curves_fitting',0.5),'r-')
% set(line1,'LineWidth',2)
% 
% line1=plot(timevect,quantile(curves_fitting',0.025),'r--')
% set(line1,'LineWidth',2)
% 
% line1=plot(timevect,quantile(curves_fitting',0.975),'r--')
% set(line1,'LineWidth',2)

%line1=plot(timevect,data1,'bo')
%set(line1,'LineWidth',2)

% hold on
% 
% set(gca,'FontSize', 15);
% set(gcf,'color','white')
% 
% grayColor = [.7 .7 .7];
% plot(length(timevect):length(timevect)+length(timevect2), curvesforecasts_age_specific5(length(timevect):end,:),'color',grayColor)
% hold on
% curves_forecast= curvesforecasts_age_specific5(length(timevect):end,:);
% line1=plot(length(timevect):length(timevect)+length(timevect2),quantile(curves_forecast',0.5),'r')
% set(line1,'LineWidth',2)
% 
% line1=plot(length(timevect):length(timevect)+length(timevect2),quantile(curves_forecast',0.025),'r--')
% set(line1,'LineWidth',2)

% line1=plot(length(timevect):length(timevect)+length(timevect2),quantile(curves_forecast',0.975),'r--')
% set(line1,'LineWidth',2)
% 
% xlabel('\fontsize{15}Time (bi-weeks)');
% ylabel('\fontsize{15}Reported measles incidence')

%xlim([0 34])

% plot time series data
% line1=plot(data1,'ko')
% set(line1,'LineWidth',2)

% plot vertical line separating calibration versus forecast periods
%line2=[timevect(end) 0;timevect(end) max(data1)*2];

%axis([timevect(1) timevect2(end) 0 max(data(:,2))*2])

% line1=plot(line2(:,1),line2(:,2),'k--')
% set(line1,'LineWidth',2)



% xticks(1:10:51); 
% xticklabels({'2000', '2010', '2020', '2030', '2040', '2050'});

% save data with results
% save(strcat('Forecast-GGM-M-',num2str(M),'-tf-',num2str(t_window(end)),'-horizon-',num2str(forecastingperiod),'-flag-',num2str(flag1),'-dist-',num2str(dist1),'-factor-',num2str(factor1),'-w-',num2str(alpha1),'-',datafilename1(1:end-4),'.mat'),'-mat')


% save('age_specific_cases1.mat','curvesforecasts_age_specific1');
% save('age_specific_cases2.mat','curvesforecasts_age_specific2');
% save('age_specific_cases3.mat','curvesforecasts_age_specific3');
% save('age_specific_cases4.mat','curvesforecasts_age_specific4');
% save('age_specific_cases5.mat','curvesforecasts_age_specific5');
% save('age_specific_cases6.mat','curvesforecasts_age_specific6');
% save('age_specific_cases7.mat','curvesforecasts_age_specific7');
% save('age_specific_cases8.mat','curvesforecasts_age_specific8');
% save('age_specific_cases9.mat','curvesforecasts_age_specific9');
% save('age_specific_cases10.mat','curvesforecasts_age_specific10');
% save('age_specific_cases_all.mat','curvesforecasts1');

% figure(3)
% % Data
% y = [mean(curvesforecasts_age_specific1(1,:)) mean(curvesforecasts_age_specific2(1,:)) mean(curvesforecasts_age_specific3(1,:)) mean(curvesforecasts_age_specific4(1,:)) mean(curvesforecasts_age_specific5(1,:)) mean(curvesforecasts_age_specific6(1,:)) mean(curvesforecasts_age_specific7(1,:)) mean(curvesforecasts_age_specific8(1,:)) mean(curvesforecasts_age_specific9(1,:)) mean(curvesforecasts_age_specific10(1,:))];          % Bar heights
% errors = [std(curvesforecasts_age_specific1(1,:)) std(curvesforecasts_age_specific2(1,:)) std(curvesforecasts_age_specific3(1,:)) std(curvesforecasts_age_specific4(1,:)) std(curvesforecasts_age_specific5(1,:)) std(curvesforecasts_age_specific6(1,:)) std(curvesforecasts_age_specific7(1,:)) std(curvesforecasts_age_specific8(1,:)) std(curvesforecasts_age_specific9(1,:)) std(curvesforecasts_age_specific10(1,:))];     % Error values
% 
% % Create bar plot
% figure;
% y1=[303 738 1142 2629 3204 2031 2074 1851 5844 551]/7;
% yy1=y1/sum(y1);
% % b = bar(y);
% y_combined = [y1; yy1]';
% 
% % Create the grouped bar plot
% b = bar(y_combined, 'grouped');
% hold on;
% 
% % Add error bars
% er = errorbar(1:length(y), y, errors, 'k', 'LineStyle', 'none'); 
% 
% % Customize appearance
% er.LineWidth = 1.5;          % Thickness of the error bars
% b.FaceColor = [0.2 0.6 0.8]; % Change color of bars
% b.EdgeColor = 'none';        % Remove bar edges
% 
% % Add labels
% xlabel('Age classes');
% ylabel('Reported measles incidence');
% title('Bar Plot with Error Bars');
% 
% hold off;



%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%
% Age_pop_UP_2011_total=78937187; %1059633675;
% Age_pop_UP_2011 = (1/100)*[12.3/16*ones(1,4), 12.3/4*ones(1,4), 22.8, 64.9]*Age_pop_UP_2011_total;
% %Age_pop_UP_2011_total_S=0.2*sum(Age_pop_UP_2011(4:9));

% COMPARISON AGE SPECIFIC CASES
%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%

% set(gca,'FontSize', 12);
% % y = [mean(curvesforecasts_age_specific1(end-2-26,:)), mean(curvesforecasts_age_specific2(end-2-26,:)), mean(curvesforecasts_age_specific3(end-2-26,:)), mean(curvesforecasts_age_specific4(end-2-26,:)), mean(curvesforecasts_age_specific5(end-2-26,:)), mean(curvesforecasts_age_specific6(end-2-26,:)), mean(curvesforecasts_age_specific7(end-2-26,:)), mean(curvesforecasts_age_specific8(end-2-26,:)), mean(curvesforecasts_age_specific9(end-2-26,:)), mean(curvesforecasts_age_specific10(end-2-26,:))];  % Bar heights
% % errors = [std(curvesforecasts_age_specific1(end-2-26,:)), std(curvesforecasts_age_specific2(end-2-26,:)), std(curvesforecasts_age_specific3(end-2-26,:)), std(curvesforecasts_age_specific4(end-2-26,:)), std(curvesforecasts_age_specific5(end-2-26,:)), std(curvesforecasts_age_specific6(end-2-26,:)), std(curvesforecasts_age_specific7(end-2-26,:)), std(curvesforecasts_age_specific8(end-2-26,:)), std(curvesforecasts_age_specific9(end-2-26,:)), std(curvesforecasts_age_specific10(end-2-26,:))];  % Error values
% % b = bar(y, 'grouped');
% 
% y = [mean(curvesforecasts_age_specific1(1,:)), mean(curvesforecasts_age_specific2(1,:)), mean(curvesforecasts_age_specific3(1,:)), mean(curvesforecasts_age_specific4(1,:)), mean(curvesforecasts_age_specific5(1,:)), mean(curvesforecasts_age_specific6(1,:)), mean(curvesforecasts_age_specific7(1,:)), mean(curvesforecasts_age_specific8(1,:)), mean(curvesforecasts_age_specific9(1,:)), mean(curvesforecasts_age_specific10(1,:))];  % Bar heights
% errors = [std(curvesforecasts_age_specific1(1,:)), std(curvesforecasts_age_specific2(1,:)), std(curvesforecasts_age_specific3(1,:)), std(curvesforecasts_age_specific4(1,:)), std(curvesforecasts_age_specific5(1,:)), std(curvesforecasts_age_specific6(1,:)), std(curvesforecasts_age_specific7(1,:)), std(curvesforecasts_age_specific8(1,:)), std(curvesforecasts_age_specific9(1,:)), std(curvesforecasts_age_specific10(1,:))];  % Error values
% b = bar(y, 'grouped');
% y = [mean(curvesforecasts_age_specific1(end,:)), mean(curvesforecasts_age_specific2(end,:)), mean(curvesforecasts_age_specific3(end,:)), mean(curvesforecasts_age_specific4(end,:)), mean(curvesforecasts_age_specific5(end,:)), mean(curvesforecasts_age_specific6(end,:)), mean(curvesforecasts_age_specific7(end,:)), mean(curvesforecasts_age_specific8(end,:)), mean(curvesforecasts_age_specific9(end,:)), mean(curvesforecasts_age_specific10(end,:))];  % Bar heights
% errors = [std(curvesforecasts_age_specific1(end,:)), std(curvesforecasts_age_specific2(end,:)), std(curvesforecasts_age_specific3(end,:)), std(curvesforecasts_age_specific4(end,:)), std(curvesforecasts_age_specific5(end,:)), std(curvesforecasts_age_specific6(end,:)), std(curvesforecasts_age_specific7(end,:)), std(curvesforecasts_age_specific8(end,:)), std(curvesforecasts_age_specific9(end,:)), std(curvesforecasts_age_specific10(end,:))];  % Error values
% b = bar(y, 'grouped');
% y_matrix = [];errors_matrix =[];
% for mmm=1:27
% y = [mean(curvesforecasts_age_specific1(end-mmm*26,:)), mean(curvesforecasts_age_specific2(end-mmm*26,:)), mean(curvesforecasts_age_specific3(end-mmm*26,:)), mean(curvesforecasts_age_specific4(end-mmm*26,:))];  % Bar heights
% errors = [std(curvesforecasts_age_specific1(end-mmm*26,:)), std(curvesforecasts_age_specific2(end-mmm*26,:)), std(curvesforecasts_age_specific3(end-mmm*26,:)), std(curvesforecasts_age_specific4(end-mmm*26,:))];  % Error values
% y_matrix=[y_matrix; y];
% errors_matrix =[error_matrix; errors];
% end
% b = bar(y, 'grouped');
% 
% 
% hold on;
% x = b(1).XEndPoints;
% er = errorbar(x, y, errors, 'k', 'LineStyle', 'none'); hold on
% 
% 
% % for i = 4:length(y)
% %     lower_bound = y(i) - errors(i);
% %     upper_bound = y(i) + errors(i);
% %     text(x(i), y(i) + errors(i), sprintf('[%.2f, %.2f]', lower_bound, upper_bound), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', 'FontSize', 10);
% % end
% 
% er.LineWidth = 1.5;       
% xlabel('Age classes');
% ylabel('Estimated proportion of susceptible population');
% % xticks(4:10);
% % xticklabels({'<1 year', '1-2 years', '2-3 years', '3-4 years', '4-5 years', '5-15 years', '>15 years'});
% % set(gca, 'FontSize', 10);
% % hold off;
% % %xlim([3 11]);
% % ylim([0 0.20]);









%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%

% Define the years from 2024 to 2050
set(gca,'FontSize',5)
years = 2000:2023;

% Initialize y_matrix and errors_matrix
y_matrix = []; 
errors_matrix = [];

% Generate y_matrix and errors_matrix
for mmm = 1:24
    y = [mean(curvesforecasts_age_specific1(26*mmm,:)), ...
         mean(curvesforecasts_age_specific2(26*mmm,:)), ...
         mean(curvesforecasts_age_specific3(26*mmm,:)), ...
            ];  % Bar heights
    errors = [std(curvesforecasts_age_specific1(26*mmm,:)), ...
              std(curvesforecasts_age_specific2(26*mmm,:)), ...
              std(curvesforecasts_age_specific3(26*mmm,:)), ...
             ];  % Error values
    y_matrix = [y_matrix; y];
    errors_matrix = [errors_matrix; errors];
end

% Define deeper colors for each bar section
colors = [0.0 0.3 0.6;  % Deep blue
          0.0 0.5 0.0;  % Deep green
          0.8 0.0 0.0;  % Deep red
          0.6 0.6 0.0]; % Deep yellow

% Define light colors for error bars
light_colors = [0.4 0.7 1.0;  % Light blue
                0.6 1.0 0.6;  % Light green
                1.0 0.6 0.6;  % Light red
                0.9 0.9 0.4]; % Light yellow

% Create a figure for the plot
figure;

% Loop through each year and plot stacked bars
for k = 1:length(years)
    y = y_matrix(k, :);  % Extract y-values for this year
    errors = errors_matrix(k, :);  % Extract errors for this year
    
    % Create a stacked bar plot for the current year
    b = bar(k, y, 'stacked');  % Use 'stacked' option to stack the bars
    hold on;
    
    % Assign deep colors to each segment of the stacked bar
    for i = 1:length(y)
        b(i).FaceColor = colors(i, :);  % Set the color for each segment
    end

    % Calculate cumulative heights for stacking
    stacked_heights = cumsum(y);

    % Alternating offsets for error bars
    offsets = [-0.05, 0.05];  % Alternate between left and right for error bars

    % Plot error bars for each stacked section at the top of each color
    for i = 1:length(y)
        % Set the position of the error bar at the top of the current stack
        xpos = k + offsets(mod(i, 2) + 1);  % Alternate between left and right
        
        % Add error bars at the top of each stacked section with light colors
        errorbar(xpos, stacked_heights(i), errors(i), 'LineStyle', 'none', 'Color', light_colors(i, :), 'LineWidth', 1.5);
        
        % Add text labels for each segment in the middle of each section
        % text(k, (stacked_heights(i) - y(i)/2), sprintf('%.2f', y(i)), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', 'FontSize', 10, 'Color', 'k');
    end
end

% Add legend to explain the colors
legend({'Age Class 1', 'Age Class 2', 'Age Class 3'}, 'Location', 'northeastoutside');

% Add labels and title
xlabel('Year');
ylabel('Estimated age-specific proportion of susceptible');

% Set the x-axis ticks to the years
xticks(1:length(years));
xticklabels(string(years));

% Adjust the y-axis limits and ticks
ylim([0 max(sum(y_matrix, 2)) + max(max(errors_matrix)) + 0.05]);  % Make space for error bars

hold off;
