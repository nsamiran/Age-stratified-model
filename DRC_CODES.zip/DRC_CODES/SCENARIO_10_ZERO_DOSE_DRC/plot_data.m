clear all
clc
%% import data

cases_DRC = [1678 2152 2788 3712 3524 146 126 84 2 1 4 315 260 124 71.00 1359.00 ...
277 958 28 66.00 37.00 160.00 6718.00 385.00];

timescl = 2000:1:2023;

SIA_coverage = [19.3 23.5 0.5 35.3 27.6 22.9 26.7 38.5 27.8 23.1 11.7 15.2 23.7 3.8 ...
43.4 2.4 21.5 1.5 29.9 18.5 23.3 26.4 11.9 4.9 12.2 55.7 28.6 41.2];
SIA_timing = 2000+[0, 3, 3, 4, 5, 6, 6, 7, 8, 9, 10, 11, 11, 11, 11, 11, 12, 12, 13, ...
    13, 14, 14 ,14, 14, 14, 16, 16, 17];

MCV1_coverage=[ 34, 35, 37, 50, 65, 54, 61, 59, 69, 63, 75, 83, 80, 80, 80, 80, ...
67, 70, 75, 73, 68, 68, 65, 65];
 
MCV2_coverage=[zeros(1,19), 9, 29, 31, 34, 34];

yyaxis right
b1=bar(timescl, cases_DRC, 'r') ;
b1.FaceAlpha = 0.2;
yyaxis left
plot(timescl,MCV1_coverage,'k-','LineWidth', 1.5)
hold on
plot(timescl,MCV2_coverage,'b--','LineWidth', 1.5)
hold on
plot(SIA_timing, SIA_coverage,'ro')
H=gca;
H.LineWidth=1; %change to the desired value     