load('age_specific_cases_all.mat')
y=quantile(curvesforecasts1',0.5)*1000000*(1/0.0165)/232679477; %cases per million with population at 2024 (populationpyramid)
j=find(y(24:end)<5); 
year = 2023+j(1)
three_years_cases = [y(23+j(1)) y(24+j(1)) y(25+j(1))] 
plot(y)
