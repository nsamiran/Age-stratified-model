clear all
close all
clc

load curves.mat
load Phatss.mat

data1=[212183 168107 42007 141258 31521 110927 704 2613 9960 1272 8491 18843 6447 52852 6855 12423 17136 11190 7063 28094 8877 10649 23983 20143];

DT=1; % temporal resolution of the data in days

% create time vector in days
timevect=1:length(data1);

% number of bootstrap realizations
M=1000;
% estimate mean and 95% CI from distribution of parameter estimates
param_alpha111=[mean(Phatss(:,1)) quantile(Phatss(:,1),0.025) quantile(Phatss(:,1),0.975)];
param_alpha112=[mean(Phatss(:,2)) quantile(Phatss(:,2),0.025) quantile(Phatss(:,2),0.975)];
param_alpha113=[mean(Phatss(:,3)) quantile(Phatss(:,3),0.025) quantile(Phatss(:,3),0.975)];
param_alpha114=[mean(Phatss(:,4)) quantile(Phatss(:,4),0.025) quantile(Phatss(:,4),0.975)];
param_reporting=[mean(Phatss(:,5)) quantile(Phatss(:,5),0.025) quantile(Phatss(:,5),0.975)];

cad1=strcat('alpha_111=',num2str(param_alpha111(end,1),2),' (95% CI:',num2str(param_alpha111(end,2),2),',',num2str(param_alpha111(end,3),2),')')
cad2=strcat('alpha_112=',num2str(param_alpha112(end,1),2),' (95% CI:',num2str(param_alpha112(end,2),2),',',num2str(param_alpha112(end,3),2),')')
cad3=strcat('alpha_113=',num2str(param_alpha113(end,1),2),' (95% CI:',num2str(param_alpha113(end,2),2),',',num2str(param_alpha113(end,3),2),')')
cad4=strcat('alpha_114=',num2str(param_alpha114(end,1),2),' (95% CI:',num2str(param_alpha114(end,2),2),',',num2str(param_alpha114(end,3),2),')')
cad5=strcat('reporting=',num2str(param_reporting(end,1),2),' (95% CI:',num2str(param_reporting(end,2),2),',',num2str(param_reporting(end,3),2),')')
% plot empirical distributions of r and p
% figure(1)
% subplot(2,3,1)
% hist(Phatss(:,1))
% xlabel('alpha_111')
% ylabel('Frequency')
% 
% % title(cad1)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,2)
% hist(Phatss(:,2))
% xlabel('alpha_112')
% ylabel('Frequency')
% 
% % title(cad2)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,3)
% hist(Phatss(:,3))
% xlabel('alpha_113')
% ylabel('Frequency')
% 
% % title(cad3)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,4)
% hist(Phatss(:,4))
% xlabel('alpha_114')
% ylabel('Frequency')
% 
% % title(cad4)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,3)
% hist(Phatss(:,3))
% xlabel('alpha_113')
% ylabel('Frequency')
% 
% % title(cad3)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,5)
% hist(Phatss(:,5))
% xlabel('reporting rate')
% ylabel('Frequency')
% 
% % title(cad4)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')

% plot model fit and uncertainty around model fit

% param_beta_e_time2=[];
% param_beta_h_time2=[];
% param_rho_time2=[];
% param_nu_time2=[];

%% 3) Generate short-term forecasts

close all

% forecast horizon
forecastingperiod=27; % number of data points ahead

timevect2=(1:forecastingperiod);

% vector to store forecast curves
curvesforecasts1=[]; 

% generate forecast curves from each bootstrap realization
for realization=1:M
    
%     r_hat=Phatss(realization,1);
%     p_hat=Phatss(realization,2);
    z1=Phatss(realization,:); 
%     [~,x]=ode45(@simpleGrowth,timevect2,IC,[],r_hat,p_hat,flag1);     
    
    incidence11=measles_sol1_R0(z1, timevect, timevect2);
    incidence1=incidence11;
    
    %NNN=incidence11(:,end);

    
    curvesforecasts1=[curvesforecasts1; incidence1];
   
end

% plot forecast curves
% figure(2)

%plot(curvesforecasts1');
%hold on
T_r0 = 1:(length(timevect));
curves_fitting = curvesforecasts1(:,T_r0);

%plot(T_r0,curves_fitting','r-');
hold on


%line1=plot(timevect,mean(curves,2),'r-')


line1=plot(T_r0,quantile(curves_fitting,0.025),'b-.')
set(line1,'LineWidth',2)

line1=plot(T_r0,quantile(curves_fitting,0.975),'b-.')
set(line1,'LineWidth',2)

% Fill the region between the two lines with transparent red
patch([T_r0, fliplr(T_r0)], ...
      [quantile(curves_fitting, 0.025), fliplr(quantile(curves_fitting, 0.975))], ...
      'r', 'FaceAlpha', 0.3, 'EdgeColor', 'none');
yline(1,'r-.','LineWidth',2)
hold on
line1=plot(T_r0,quantile(curves_fitting,0.5),'b-')
set(line1,'LineWidth',2)

set(gca,'FontSize', 15);
set(gcf,'color','white')

grayColor = [.7 .7 .7];
xticks([1 6 11 16 21 24]);
xticklabels([2000 2005 2010 2015 2020 2023])

xlabel('\fontsize{15} Year');
ylabel('\fontsize{15}Effective Reproduction Number')
xlim([1 24]);
ylim([0.9 1.15]);
box on
