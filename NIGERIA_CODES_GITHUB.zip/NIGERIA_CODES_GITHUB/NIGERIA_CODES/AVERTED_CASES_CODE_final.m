

% Load data and calculate the mean and standard deviation for each scenario
filePath111 = load(fullfile('ROUTINE_VAC_SCENARIO_1_NIGERIA', 'age_specific_cases_all.mat'));
filePath211 = load(fullfile('EARLY_VAC_SCENARIO_1_NIGERIA', 'age_specific_cases_all.mat'));
filePath311 = load(fullfile('ZERO_DOSE_SCENARIO_1_DRC', 'age_specific_cases_all.mat'));

var111 = filePath111.curvesforecasts1(25:end, :);
var112 = filePath211.curvesforecasts1(25:end, :);
var113 = filePath311.curvesforecasts1(25:end, :);

avar111 = sum(var111, 1);
avar112 = sum(var112, 1);
avar113 = sum(var113, 1);

averted_1 = (avar111 - avar112);
averted_1EARLY = (avar111 - avar113);

mean_averted_1 = mean(averted_1);
std_averted_1 = std(averted_1);
mean_averted_1EARLY = mean(averted_1EARLY);
std_averted_1EARLY = std(averted_1EARLY);

% Repeat the process for scenarios 2, 3, and 4
filePath111 = load(fullfile('ROUTINE_VAC_SCENARIO_1_NIGERIA', 'age_specific_cases_all.mat'));
filePath211 = load(fullfile('EARLY_VAC_SCENARIO_2_NIGERIA', 'age_specific_cases_all.mat'));
filePath311 = load(fullfile('ZERO_DOSE_SCENARIO_2_DRC', 'age_specific_cases_all.mat'));
filePath411 = load(fullfile('ROUTINE_VAC_SCENARIO_2_NIGERIA', 'age_specific_cases_all.mat'));

var111 = filePath111.curvesforecasts1(25:end, :);
var112 = filePath211.curvesforecasts1(25:end, :);
var113 = filePath311.curvesforecasts1(25:end, :);
var114 = filePath411.curvesforecasts1(25:end, :);

avar111 = sum(var111, 1);
avar112 = sum(var112, 1);
avar113 = sum(var113, 1);
avar114 = sum(var114, 1);

averted_2 = (avar111 - avar112);
averted_2EARLY = (avar111 - avar113);
averted_2ROUTINE = (avar111 - avar114);

mean_averted_2 = mean(averted_2);
std_averted_2 = std(averted_2);
mean_averted_2EARLY = mean(averted_2EARLY);
std_averted_2EARLY = std(averted_2EARLY);
mean_averted_2ROUTINE = mean(averted_2ROUTINE);
std_averted_2ROUTINE = std(averted_2ROUTINE);

% Repeat the process for scenarios 2, 3, and 4
filePath111 = load(fullfile('ROUTINE_VAC_SCENARIO_1_NIGERIA', 'age_specific_cases_all.mat'));
filePath211 = load(fullfile('EARLY_VAC_SCENARIO_3_NIGERIA', 'age_specific_cases_all.mat'));
filePath311 = load(fullfile('ZERO_DOSE_SCENARIO_3_DRC', 'age_specific_cases_all.mat'));
filePath411 = load(fullfile('ROUTINE_VAC_SCENARIO_3_NIGERIA', 'age_specific_cases_all.mat'));

var111 = filePath111.curvesforecasts1(25:end, :);
var112 = filePath211.curvesforecasts1(25:end, :);
var113 = filePath311.curvesforecasts1(25:end, :);
var114 = filePath411.curvesforecasts1(25:end, :);

avar111 = sum(var111, 1);
avar112 = sum(var112, 1);
avar113 = sum(var113, 1);
avar114 = sum(var114, 1);

averted_3 = (avar111 - avar112);
averted_3EARLY = (avar111 - avar113);
averted_3ROUTINE = (avar111 - avar114);

mean_averted_3 = mean(averted_3);
std_averted_3 = std(averted_3);
mean_averted_3EARLY = mean(averted_3EARLY);
std_averted_3EARLY = std(averted_3EARLY);
mean_averted_3ROUTINE = mean(averted_3ROUTINE);
std_averted_3ROUTINE = std(averted_3ROUTINE);
% Calculate for scenario 4
% Repeat the process for scenarios 2, 3, and 4
filePath111 = load(fullfile('ROUTINE_VAC_SCENARIO_1_NIGERIA', 'age_specific_cases_all.mat'));
filePath211 = load(fullfile('EARLY_VAC_SCENARIO_4_NIGERIA', 'age_specific_cases_all.mat'));
filePath311 = load(fullfile('ZERO_DOSE_SCENARIO_4_DRC', 'age_specific_cases_all.mat'));
filePath411 = load(fullfile('ROUTINE_VAC_SCENARIO_4_NIGERIA', 'age_specific_cases_all.mat'));

var111 = filePath111.curvesforecasts1(25:end, :);
var112 = filePath211.curvesforecasts1(25:end, :);
var113 = filePath311.curvesforecasts1(25:end, :);
var114 = filePath411.curvesforecasts1(25:end, :);

avar111 = sum(var111, 1);
avar112 = sum(var112, 1);
avar113 = sum(var113, 1);
avar114 = sum(var114, 1);

averted_4 = (avar111 - avar112);
averted_4EARLY = (avar111 - avar113);
averted_4ROUTINE = (avar111 - avar114);

mean_averted_4 = mean(averted_4);
std_averted_4 = std(averted_4);
mean_averted_4EARLY = mean(averted_4EARLY);
std_averted_4EARLY = std(averted_4EARLY);
mean_averted_4ROUTINE = mean(averted_4ROUTINE);
std_averted_4ROUTINE = std(averted_4ROUTINE);

% Combine results for plotting
mean_averted = [mean_averted_4ROUTINE, mean_averted_3ROUTINE, mean_averted_2ROUTINE, mean_averted_1, mean_averted_4, mean_averted_3, mean_averted_2, ...
                mean_averted_1EARLY, mean_averted_4EARLY, mean_averted_3EARLY, mean_averted_2EARLY];
std_averted = [std_averted_4ROUTINE, std_averted_3ROUTINE, std_averted_2ROUTINE, std_averted_1, std_averted_4, std_averted_3, std_averted_2, ...
               std_averted_1EARLY, std_averted_4EARLY, std_averted_3EARLY, std_averted_2EARLY];

% Define prominent, distinct colors
colors = [0, 0, 1;      % Blue
          1, 0, 0;      % Red
          0, 1, 0;      % Green
          1, 0.5, 0;    % Orange
          0.5, 0, 0.5;  % Purple
          0, 1, 1;      % Cyan
          1, 1, 0;      % Yellow
          0.5, 0.5, 0.5; % Gray
          0.6, 0.2, 0;   % Brown
          1, 0.75, 0.8; % Pink
          0.2, 0.6, 1]; % Light Blue

% Plot the bar graph
figure;
for i = 1:length(mean_averted)
    bar(i, mean_averted(i), 'FaceColor', colors(mod(i-1, size(colors, 1)) + 1, :), 'EdgeColor', 'k', 'LineWidth', 1.5); % Individual bar with unique color
    hold on;
end

% Add error bars
errorbar(1:length(mean_averted), mean_averted, std_averted, 'k.', 'LineWidth', 1.5);

xticks(1:11);

% Optionally, label the x-ticks (if needed)
xticklabels(1:11);

% Customize the plot
xlabel('Scenarios', 'FontSize', 12);
ylabel('Total averted cases', 'FontSize', 12);
title('Nigeria', 'FontSize', 15);
grid on;
set(gca, 'FontSize', 12);

% Improve overall aesthetics
box on;
axis tight;
ylim([0 15*10^5])
