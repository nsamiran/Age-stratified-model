
clear all;
close all;

%% Sample size N
runs=5000;

%% LHS MATRIX  %%
% parameters;

alpha11=0.7; alpha12 = 0.3; alpha13 = 0.1; alpha14=0.01;
alpha21 = 0.5; epsilon11=0.9; epsilon21 = 0.85; mcv1_cov1 = 0.8;
mcv2_cov1=0.6;

alpha11_LHS=LHS_Call(1e-7, alpha11, 1, 0 ,runs,'unif'); 
alpha12_LHS=LHS_Call(1e-7, alpha12, 1, 0 ,runs,'unif'); 
alpha13_LHS=LHS_Call(1e-7, alpha13, 1, 0 ,runs,'unif'); 
alpha14_LHS=LHS_Call(1e-7, alpha14, 1, 0 ,runs,'unif'); 
alpha21_LHS=LHS_Call(1e-7, alpha21, 1, 0, runs,'unif'); 
epsilon11_LHS=LHS_Call(1e-7,epsilon11,0.95, 0 ,runs,'unif'); 
epsilon21_LHS=LHS_Call(1e-7, epsilon21, 0.99, 0, runs,'unif'); 
mcv1_cov1_LHS=LHS_Call(1e-7, mcv1_cov1, 1, 0 ,runs,'unif');
mcv2_cov1_LHS=LHS_Call(1e-7, mcv2_cov1, 1, 0 ,runs,'unif'); 

% LHS MATRIX and PARAMETER LABELS................
LHSmatrix=[alpha11_LHS alpha12_LHS alpha13_LHS alpha14_LHS alpha21_LHS epsilon11_LHS epsilon21_LHS mcv1_cov1_LHS mcv2_cov1_LHS]';


%% Save the workspace
save Model_LHS_measles.mat;
