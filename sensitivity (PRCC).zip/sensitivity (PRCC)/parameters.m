%%%%%%%%%%%%%%parameters%%%%%%%%%%%%%%
%%%%%%%fixed parameter%%%%%%%
b_h = 0.0324/52; % SRS 1997
b_v = 1.25; % Norman et al - 5 per month
mu_h = 0.0105/52; % SRS 1997
mu_v = 1.25; % Norman et al - 5 per month
pi_h = b_h*100000;
pi_v = b_v*100000*3; % singh et al
%lambda_v = 7/11; % MDA ppt suchita
% theta_hv = 0.37; % 
% i1 = 0.000004; % Singh et al
% alpha1 = 1/(7.5*52); % development of ADL after developing microfilaria 1/(7.5)
%beta1 = 2.5; %
% theta_vh = 0.000113;
%assumed parameters
% omega_E = 0.0076; %assumed 
% lambda_E = 0.4; % n*psi_2/time
% omega_W = 0.0006; % probality that a person has only male or only 
%                 % female adult worms taking total worm number is 5
% lambda_W = 0.0013; % probality that a person has atleat one male and one 
%                 % female adult worm taking total worm number is 5 2/(3*10.2*52)

% beta1=1; alpha_1=0.4;
%% Parameter Labels 
PRCC_var={'\beta','\theta_{hv}', '\theta_{vh}', '\lambda_E', '\omega_E', '\lambda_W', '\omega_W', '\alpha' , 'i', '\lambda_v'};% 

% tspan = 1:1:60;