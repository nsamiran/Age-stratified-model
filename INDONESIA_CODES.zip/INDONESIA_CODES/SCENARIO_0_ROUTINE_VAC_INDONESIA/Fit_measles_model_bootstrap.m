% @ Indrajit Ghosh, Samiran Ghosh

% Last modification: 26/09/2024

%% 1) Fitting measles model to data
clc
clear
% close all

data1=[3344 3825 14492 24457 29171 15853 20422 19456 15369 20818 18869 21893 15489 8419 12943 15099 6962 9035 5300 1965 524 394 7704 18063];
y1=[0 0 766.4 510.94 813.34 90.65 90.65 90.65 76.66 20.87];
datay1=[data1 y1];
DT=1; % temporal resolution of the data in days

% create time vector
timevect=1:length(data1);

% initial guesses for parameters
% param=[0.9094, 0.0529, 0.001, 0.0001, 0.0150 0.9];
param=[0.9094, 0.279, 0.09, 0.0009, 0.0250 0.9];

z(1)=param(1);
z(2)=param(2);
z(3)=param(3);
z(4)=param(4);
z(5)=param(5);
z(6)=param(6);%alpha_2 


% LB = double([0.3, 0, 0.01, 0.0001, 0.01 0.001]); % lower bound of the parameters 
% UB = double([1.1, 0.75, 0.25, 0.05, 0.05 1]); % upper bound of the parameters
% 
LB = double([0.3, 0.09, 0.08, 0.0008, 0.009 0.001]); % lower bound of the parameters 
UB = double([2.1, 0.75, 0.25, 0.05, 0.05 1]); % upper bound of the parameters


% LB = double([0.01, 0, 0.01, 0.0001, 0.001 0.0001]); % lower bound of the parameters 
% UB = double([1, 1.95, 1.95, 0.9, 0.1 1.5]); % upper bound of the parameters

% Define the weight vector (higher weights for the last 10 points)
weights = ones(size(datay1));         % Initialize all weights to 1
weights(end-9:end) = 0;              % Increase the weights for the last 10 points

% Modify the lsqcurvefit call with the weighted residuals
weighted_datay1 = @(P, z) weights .* (measles_sol2(P, z) - datay1).^2;
options = optimoptions('lsqcurvefit', 'Display', 'off', 'Algorithm', 'trust-region-reflective');

% Obtain the best model fit
[P,resnorm,residual] = lsqcurvefit(weighted_datay1, z, timevect, datay1, LB, UB, options);



% options = optimoptions('lsqcurvefit', 'Display', 'off', 'Algorithm', 'trust-region-reflective');
% 
% % obtain the best model fit
% [P,resnorm,residual]=lsqcurvefit(@measles_sol2,z,timevect,datay1,LB,UB,options);

% P is the vector with the estimated parameters
param1=P;
% obtaian the incidence curve
%incidence1=measles_sol(param1, timevect);
incidence11=measles_sol2(param1, timevect);
incidence1=incidence11(1:end-10);
% plot the model fit and data
% figure
subplot(1,3,1)
line2=plot(timevect,incidence1,'r')
set(line2,'LineWidth',2)
% axis([10 30 -50 500]);
hold on

line2=plot(timevect,data1,'bo')
set(line2,'LineWidth',2)

xlabel('Time (days)');
ylabel('Incidence')
legend('Model','Data')

set(gca,'FontSize', 24);
set(gcf,'color','white')

% plot the residuals
subplot(1,3,2)
resid=(incidence1-data1);
scaledresid=resid./std(resid);

stem(timevect,resid)

xlabel('Time (days)');
ylabel('Residuals')

set(gca,'FontSize', 24);
set(gcf,'color','white')

subplot(1,3,3)
line2=plot(incidence11(end-9:end),'r')
set(line2,'LineWidth',2)
% axis([10 30 -50 500]);
hold on

line2=plot(datay1(end-9:end),'bo')
set(line2,'LineWidth',2)

% goodness of fit metrics
SSE=sum((incidence1-data1).^2);

RMSE=sqrt(mean((incidence1-data1).^2))
MAE=mean(abs(incidence1-data1))
MAPE=mean(abs((incidence1-data1)./data1))

%% 2) Derive parameter uncertainty

% close all

% no weights used for generating parameter uncertainty
% weights=ones(length(t_window),1);

% number of bootstrap realizations
M=1000;

%distribution for data variation (dist1=1 for Poisson, dist1=2 for negative
%binomial, variance is mean1*factor1
dist1=1;
factor1=1;

% parameter estimates
% Ptrue=[beta_e_hat beta_h_hat rho_hat nu_hat];
Ptrue=[param(1) param(2) param(3) param(4) param(5) param(6)];


Phatss=zeros(M,6); % vector that will store parameter estimates from each realization
SSEs=zeros(M,1); % SSE for each realization
curves=[]; 

% generate each of the M realizations
for realization=1:M
    
    % bootstrap realization is generated
    
    yirData=zeros(length(incidence1)+length(y1),1);
    
    % yirData(1)=F(1,3);
    
    
    if dist1==1         %Poisson dist. error structure
        for t=1:length(incidence1)
            newcases_t=incidence1(t);
 %           yirData(t,1)=poissrnd(newcases_t,1,1);
         %     yirData(t,1)=normrnd(newcases_t,sqrt(newcases_t),1,1);
            yirData(t,1)=normrnd(newcases_t,0.2*newcases_t,1,1);
        end

         for t=length(incidence1)+1:length(incidence1)+length(y1)
            %newcases_t=incidence1(t);
 %           yirData(t,1)=poissrnd(newcases_t,1,1);
         %     yirData(t,1)=normrnd(newcases_t,sqrt(newcases_t),1,1);
         MMod=1+mod(t-length(incidence1),length(y1));
            yirData(t,1)=y1(MMod);
        end


        
    % elseif dist1==2         % Negative binomial dist. error structure
    %     for t=2:length(F)
    %         newcases_t=F(t,3)-F(t-1,3);
    %         mean1=newcases_t;
    %         var1=mean1*factor1
    % 
    %         param2=mean1/var1;
    %         param1=mean1*param2/(1-param2);
    % 
    %         yirData(t,1)=nbinrnd(param1,param2,1,1);
    %     end
        
    end
    
    % store realiation of the epidemic curve
    curves=[curves yirData];

    % Estimate parameters from bootstrap realization
    
    % initial values for parameters
   
   
    z(1)=param(1);% initial guesses
    z(2)=param(2);
    z(3)=param(3);
    z(4)=param(4);
    z(5)=param(5);
    z(6)=param(6);

    
    hold on
        
    weighted_datay1 = @(P, z) weights .* (measles_sol2(P, z) - yirData').^2;
options = optimoptions('lsqcurvefit', 'Display', 'off', 'Algorithm', 'trust-region-reflective');

% Obtain the best model fit
[P,resnorm,residual] = lsqcurvefit(weighted_datay1, z, timevect, yirData', LB, UB, options);



    % options=[]; % by default employ the trust-region reflective algorithm - numerical optimization method
    % options = optimoptions('lsqcurvefit', 'Display', 'off', 'Algorithm', 'trust-region-reflective');
    % 
    % 
    % [P,resnorm,residual]=lsqcurvefit(@measles_sol2,z,timevect,yirData',LB,UB,options);
        
    % P is the vector with the estimated parameters from the realization
    param2=P
    % Stores estimated parameters for each realization of a total of M realizations
    Phatss(realization,:)=P; 
    
end

save('curves.mat','curves')
save('Phatss.mat','Phatss')

% param_alpha111=[mean(Phatss(:,1)) plims(Phatss(:,1),0.1) plims(Phatss(:,1),0.9)];
% param_alpha112=[mean(Phatss(:,2)) plims(Phatss(:,2),0.1) plims(Phatss(:,2),0.9)];
% param_alpha113=[mean(Phatss(:,3)) plims
% (Phatss(:,3),0.1) plims(Phatss(:,3),0.9)];
% param_alpha114=[mean(Phatss(:,4)) plims(Phatss(:,4),0.1) plims(Phatss(:,4),0.9)];
% param_reporting=[mean(Phatss(:,5)) plims(Phatss(:,5),0.1) plims(Phatss(:,5),0.9)];
% 
% cad1=strcat('alpha_111=',num2str(param_alpha111(end,1),2),' (95% CI:',num2str(param_alpha111(end,2),2),',',num2str(param_alpha111(end,3),2),')')
% cad2=strcat('alpha_112=',num2str(param_alpha112(end,1),2),' (95% CI:',num2str(param_alpha112(end,2),2),',',num2str(param_alpha112(end,3),2),')')
% cad3=strcat('alpha_113=',num2str(param_alpha113(end,1),2),' (95% CI:',num2str(param_alpha113(end,2),2),',',num2str(param_alpha113(end,3),2),')')
% cad4=strcat('alpha_114=',num2str(param_alpha114(end,1),2),' (95% CI:',num2str(param_alpha114(end,2),2),',',num2str(param_alpha114(end,3),2),')')
% cad5=strcat('reporting=',num2str(param_reporting(end,1),2),' (95% CI:',num2str(param_reporting(end,2),2),',',num2str(param_reporting(end,3),2),')')
% % plot empirical distributions of r and p
% figure
% subplot(2,3,1)
% hist(Phatss(:,1))
% xlabel('alpha_111')
% ylabel('Frequency')
% 
% % title(cad1)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,2)
% hist(Phatss(:,2))
% xlabel('alpha_112')
% ylabel('Frequency')
% 
% % title(cad2)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,3)
% hist(Phatss(:,3))
% xlabel('alpha_113')
% ylabel('Frequency')
% 
% % title(cad3)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,6)
% hist(Phatss(:,4))
% xlabel('alpha_114')
% ylabel('Frequency')
% 
% % title(cad4)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% % plot model fit and uncertainty around model fit
% 
% param_beta_e_time2=[];
% param_beta_h_time2=[];
% param_rho_time2=[];
% param_nu_time2=[];
% 
% subplot(2,3,[4 5])
% plot(timevect,curves,'c-')
% hold on
% 
% %line1=plot(timevect,mean(curves,2),'r-')
% line1=plot(timevect,plims(curves',0.5),'r-')
% set(line1,'LineWidth',2)
% 
% line1=plot(timevect,plims(curves',0.1),'r--')
% set(line1,'LineWidth',2)
% 
% line1=plot(timevect,plims(curves',0.9),'r--')
% set(line1,'LineWidth',2)
% 
% line1=plot(timevect,data1,'bo')
% set(line1,'LineWidth',2)
% 
% hold on
% 
% xlabel('Time (weeks)');
% ylabel('Case incidence')
% 
% set(gca,'FontSize', 20);
% set(gcf,'color','white')
% 
% 
