function y=measles_sol1(param, timevect, timevect2)

add_years=30; 

SIA_timing = add_years*26+[1, 1*26, 10*26+11*2, 11*26+4*2, 11*26+12*2, 12*26+3*2, 12*26+12*2, 13*26+6*2, ...
     17*26+2*2, 17*26+4*2, 17*26+8*2, 17*26+9*2, 17*26+12*2, 18*26+2*2, 18*26+3*2, 18*26+5*2, ...
     18*26+6*2, 18*26+7*2, 18*26+9*2, 18*26+10*2, 18*26+11*2, 18*26+12*2, 19*26+2*2];
 
v_base_SIA1=[0.7, 0.9, 3.6, 1, 10.7, 3.5, 15.7, 14.4, 4.3, 4.6, 3, 3, 2.5, 0.1, 3, 0.3, ...
0, 3.8, 3.9, 5.4, 3.4, 27.2, 16.5]/100;
 
 MCV1_coverage=[zeros(1,10), 0, 0, 0, 0, 0, 1, 10, 24, 32, 42, 56, 43, 51, 59, 67, 72, 66, 55, 53, 56,...
     56, 57, 56, 60, 64, 68, 69, 70, 72, 78, 82, 84, 83, 83, 85, 87, 88, 90, 93, 95, 89, 89, 95, 93]/(100*6);

 MCV2_coverage=[zeros(1,add_years), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 36, 51, 60, 69, 76, 80, 82, 84, 81,...
     82, 90, 90]/(100*26);

n = 10; % Number of age groups
T = (length(timevect)+add_years)*26; % Total time in days
dt = 1; % Time step
num_steps = T/dt;

India	= [65150	40967 5700	5604	10430	19474	12032	17250	30168	26530	8285	3305	33634	31458	56188	44258	41144	64185	36711	55443	47147	40044	51780	38835];

I_data2 = India(end:-1:1);
I_data1(1)=mean(I_data2(1:2));I_data1(length(India))=mean(I_data2(end-1:end));

for mk=2:length(India)-1
I_data1(mk)=mean(I_data2(mk-1:mk+1));
end

I_data=I_data2;

% population in age groups
Age_pop_UP_2011_total=545864267; %1059633675;
Age_pop_UP_2011 = (1/100)*[15.8/20*ones(1,4), 15.8/5*ones(1,4), 25.5, 58.7]*Age_pop_UP_2011_total;
Age_pop_UP_2011_total_S=0.2*sum(Age_pop_UP_2011(4:9));

beta_contact=ones(10,10);

    % model parameters
    alpha1=0.3686*[param(1)*ones(1,4) param(2)*ones(1,4) param(3) param(4)];
    gamma1 = (1/1) * ones(1, n); % Recovery rates for each age class
    mu = [0.0, 0.0, 0.1667, zeros(1, n-3)]; % transfer rate from M to S
    alpha2 = [0.2, 0.6, 1, zeros(1, n-3)]; % modification parameter for maternally immune class
    epsilon1 = 0.95; % efficacy of MCV1
    epsilon2 = 0.98; % efficacy of MCV2
    epsilon3 = 0.7; % efficacy of SIA
    beta_2 = 0.05; % strength of seasonality
   
    %%%%%%%%% BASE SCENARIO %%%%%%%%%%%%%

    % Preallocate arrays to store results
    M = zeros(num_steps, n);
    S = zeros(num_steps, n);
    F = zeros(num_steps, n);
    I = zeros(num_steps, n);
    R = zeros(num_steps, n);
    V1 = zeros(num_steps, n);
    V2 = zeros(num_steps, n);
    VSIA = zeros(num_steps, n);
    N = zeros(num_steps, n);
    incidence=zeros(num_steps,n);

    %age progression
    omega1=[0, (1/6)*ones(1,4), (1/26)*ones(1,4), 1/(10*26)];
    omega2=[ (1/6)*ones(1,4), (1/26)*ones(1,4), 1/(10*26),0];
    omega11=[0, (1/6)*ones(1,2), (0)*ones(1,6), 0];
    omega22=[ (1/6)*ones(1,2), (0)*ones(1,6), 0,0];

   % Initial conditions  
    M(1,:) = [Age_pop_UP_2011(1:3), zeros(1,n-3)]; %initial maternally immune people
    y1=[0 0 0 962.58 610.71 68.22 68.22 68.22 57.72 14.93];
    yy1=y1/sum(y1);
    S(1,:)=Age_pop_UP_2011_total_S.*yy1;
    F(1,:) = [(0.0).*Age_pop_UP_2011(1:3), (0.01).*S(1,4:end)]; % initial vaccine failure
    I(1,:) = 1*ones(1,n); % Initial infected population 370 cases in 2011
    I(1,6:10)=0;
    V1(1,:) = zeros(1, n); % initial mcv1
    V2(1,:) = zeros(1, n); % initial mcv2
    VSIA(1,:) = zeros(1, n); % initial SIA
    R(1,:)=Age_pop_UP_2011-M(1,:)-S(1,:)-F(1,:)-I(1,:)-V1(1,:)-V2(1,:)-VSIA(1,:);  % Initial recovered population in each age class
    N(1,:) = M(1,:) + S(1,:) + F(1,:) + I(1,:) + R(1,:) + V1(1,:) + V2(1,:) + VSIA(1,:);
    I_total(1) = sum(I(1,:));
    incidence_all_ages(1)= sum(I(1,:));
    incidence(1,:) = I(1,:);
    
    % Simulation using Euler method
for t = 1:num_steps-1
        % Determine if vaccination is happening at this time step
        current_time = 1+(t-1) * dt;
          
        Crude_birth_rate=40 - (24/52)*(floor(current_time/26));
        Crude_death_rate=17 - (8/52)*(floor(current_time/26));
        b = [(Crude_birth_rate/(1000*26)), zeros(1, n-1)]; % birth rate 
        d = (Crude_death_rate/(1000*26)) * ones(1, n); % death rate
          
    for jj = 1:length(MCV1_coverage)
        if ((1+(jj-1)*26 <= current_time) && (current_time < (jj)*26))
        v1 = MCV1_coverage(jj);
        v2 = MCV2_coverage(jj);
        end
    end

    v11 = [0 0 0 v1 zeros(1,6)];
    v21 = [0 0 0 0 v2 zeros(1,5)];
        
        for i = 1:n
            % Calculate the force of infection for age group i
            lambda_1(t) = 0;
            for k = 1:n
                lambda_1(t) = lambda_1(t) + (alpha1(i)*(beta_contact(i,k)*(I(t,k))))/N(t,k);
            end
            Lambda_all(t,i) = lambda_1(t);
            
            v3 = zeros(1,n);
            for jl = 1:length(SIA_timing)  % Loop through each SIA_timing event
                 if (current_time == SIA_timing(jl))
                   v3 = [0 0 0 v_base_SIA1(jl)*ones(1,6) 0]; % Apply vaccination rate from v_base_SIA corresponding to SIA_timing(j)
                 end
            end

              if t==1
                if i==1
            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            % beta_t(t)=(1-beta_2*cos(2*pi*current_time));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - d(i)*M(t,i)-omega22(i)*M(t,i); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - d(i)*S(t,i)-omega2(i)*S(t,i);
            dFidt(t,i) = -  F(t,i) * Lambda_all(t,i)*beta_t(t) - d(i)*F(t,i)-omega2(i)*F(t,i);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)-omega2(i)*R(t,i);
            dV1idt(t,i) = - d(i)*V1(t,i)-omega2(i)*V1(t,i);
            dV2idt(t,i) = - d(i)*V2(t,i)-omega2(i)*V2(t,i);
            dVSIAidt(t,i) = - d(i)*VSIA(t,i)-omega2(i)*VSIA(t,i);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);


                elseif i==10

            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            % beta_t(t)=(1-beta_2*cos(2*pi*current_time));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i))*M(t,i) - d(i)*M(t,i)+omega11(i)*M(t,i-1); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)+omega1(i)*S(t,i-1);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)+omega1(i)*F(t,i-1);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)+omega1(i)*R(t,i-1);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)+omega1(i)*V1(t,i-1);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)+omega1(i)*V2(t,i-1);
            dVSIAidt(t,i) = epsilon3*v3(i)*(S(t,i) + F(t,i)) - d(i)*VSIA(t,i)+omega1(i)*VSIA(t,i-1);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);

                else
            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            % beta_t(t)=(1-beta_2*cos(2*pi*current_time));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i))*M(t,i) - d(i)*M(t,i)+omega11(i)*M(t,i-1)-omega22(i)*M(t,i); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)+omega1(i)*S(t,i-1)-omega2(i)*S(t,i);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)+omega1(i)*F(t,i-1)-omega2(i)*F(t,i);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)+omega1(i)*R(t,i-1)-omega2(i)*R(t,i);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)+omega1(i)*V1(t,i-1)-omega2(i)*V1(t,i);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)+omega1(i)*V2(t,i-1)-omega2(i)*V2(t,i);
            dVSIAidt(t,i) = epsilon3*v3(i)*( S(t,i) + F(t,i)) - d(i)*VSIA(t,i)+omega1(i)*VSIA(t,i-1)-omega2(i)*VSIA(t,i);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);
                end
            
else

            if i==1
            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            % beta_t(t)=(1-beta_2*cos(2*pi*current_time));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i))*M(t,i) - d(i)*M(t,i)-omega22(i)*M(t,i); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)-omega2(i)*S(t,i);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)-omega2(i)*F(t,i);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)-omega2(i)*R(t,i);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)-omega2(i)*V1(t,i);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)-omega2(i)*V2(t,i);
            dVSIAidt(t,i) = epsilon3*v3(i)*( S(t,i) + F(t,i)) - d(i)*VSIA(t,i)-omega2(i)*VSIA(t,i);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);


            elseif i==10

            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            % beta_t(t)=(1-beta_2*cos(2*pi*current_time));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i))*M(t,i) - d(i)*M(t,i)+omega11(i)*M(t-1,i-1); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)+omega1(i)*S(t-1,i-1);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)+omega1(i)*F(t-1,i-1);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)+omega1(i)*R(t-1,i-1);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)+omega1(i)*V1(t-1,i-1);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)+omega1(i)*V2(t-1,i-1);
            dVSIAidt(t,i) = epsilon3*v3(i)*( S(t,i) + F(t,i)) - d(i)*VSIA(t,i)+omega1(i)*VSIA(t-1,i-1);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);

            else
             beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            % beta_t(t)=(1-beta_2*cos(2*pi*current_time));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i) )*M(t,i) - d(i)*M(t,i)+omega11(i)*M(t-1,i-1)-omega22(i)*M(t,i); 
            dSidt(t,i) = double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)+omega1(i)*S(t-1,i-1)-omega2(i)*S(t,i);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)+omega1(i)*F(t-1,i-1)-omega2(i)*F(t,i);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)+omega1(i)*R(t-1,i-1)-omega2(i)*R(t,i);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)+omega1(i)*V1(t-1,i-1)-omega2(i)*V1(t,i);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)+omega1(i)*V2(t-1,i-1)-omega2(i)*V2(t,i);
            dVSIAidt(t,i) = epsilon3*v3(i)*( S(t,i) + F(t,i)) - d(i)*VSIA(t,i)+omega1(i)*VSIA(t-1,i-1)-omega2(i)*VSIA(t,i);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);
            end
             end
            
            
        end

        M(t+1,:) = M(t,:) + dt * dMidt(t,:);
        S(t+1,:) = S(t,:) + dt * dSidt(t,:);
        F(t+1,:) = F(t,:) + dt * dFidt(t,:);
        I(t+1,:) = I(t,:) + dt * dIidt(t,:);
        R(t+1,:) = R(t,:) + dt * dRidt(t,:);
        V1(t+1,:) = V1(t,:) + dt * dV1idt(t,:);
        V2(t+1,:) = V2(t,:) + dt * dV2idt(t,:);
        VSIA(t+1,:) = VSIA(t,:) + dt * dVSIAidt(t,:);
        %incidence(t+1,:)=incidence(t,:) ;%+ dt*incidence(t,:);
        N(t+1,:) = M(t+1,:) + S(t+1,:) + F(t+1,:) + I(t+1,:) + R(t+1,:)+V1(t+1,:)+V2(t+1,:)+VSIA(t+1,:);
        I_total(t+1) = sum(I(t+1,:));
        incidence_all_ages(t+1)=sum(incidence(t+1,:));
end


% plot(incidence_all_ages_yearly1,'b','LineWidth',2);hold on

I_yearly = zeros(1, length(I_data));
    for k = 1:length(I_data)
        I_yearly(k) = sum(incidence_all_ages((k-1+add_years)*26 + 1 : (k+add_years)*26));
    end


FY=length(timevect2);
SIA_timing1 =  num_steps+1:3*26:num_steps+(FY*26);%((num_steps/26)+1:(num_steps/26)+FY)*26;
v_base_SIA11= 1*0.165;
% efficacy reduction
 epsilon1 = 0.95-0.25; % efficacy of MCV1
    epsilon2 = 0.98; % efficacy of MCV2
    epsilon33 = 0.7; % efficacy of SIA
 %1:(1*26):(20*26-1);  
 % MCV1_coverage=[0.55*ones(1,add_years), 0.56, 0.57, 0.56, 0.6, 0.64, 0.68, 0.69, 0.7, 0.72, 0.78, 0.82, 0.84, 0.83, 0.83, 0.85, ...
 %     0.87, 0.88, 0.9, 0.93, 0.95, 0.89]/26;
 % MCV2_coverage=[zeros(1,add_years), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.27, 0.36, 0.51, 0.6, 0.69, 0.76, 0.8, 0.82, 0.84, 0.81
 %                 ]/26;

 % MCV1_coverage=[0.55*ones(1,add_years), 0.56, 0.57, 0.56, 0.6, 0.64, 0.68, 0.69, 0.7, 0.72, 0.78, 0.82, 0.84, 0.83, 0.83, 0.85, ...
 %     0.87, 0.88, 0.9, 0.93, 0.95, 0.89, 89]/26;

 MCV1_coverage= [MCV1_coverage, 1*ones(1,FY)*0.93/6];
 MCV2_coverage= [MCV2_coverage, 1*ones(1,FY)*0.90/26];

 % Simulation using Euler method
 for t = num_steps:num_steps+(FY*26)-1
        % Determine if vaccination is happening at this time step
        current_time = 1+(t-1) * dt;         
       
        Crude_birth_rate=40 - (24/52)*(floor(current_time/26));
        Crude_death_rate=17 - (8/52)*(floor(current_time/26));
        b = [(Crude_birth_rate/(1000*26)), zeros(1, n-1)]; % birth rate 
        d = (Crude_death_rate/(1000*26)) * ones(1, n); % death rate
          

      FLO1=floor(current_time/26)+1;

      v11 = [0 0 MCV1_coverage(FLO1) zeros(1,7)];
      v21 = [0 0 0 0 MCV2_coverage(FLO1) zeros(1,5)];
      
        for i = 1:n
            % Calculate the force of infection for age group i
            lambda_1(t) = 0;
            for k = 1:n
                lambda_1(t) = lambda_1(t) + (alpha1(i)*(beta_contact(i,k)*(I(t,k))))/N(t,k);
            end

            Lambda_all(t,i) = lambda_1(t);
            
            v3 = zeros(1,n);
            for jl = 1:length(SIA_timing1)  % Loop through each SIA_timing event
                 if (current_time == SIA_timing1(jl))
                   v3 = [0 0 min(0.99,v_base_SIA11)*ones(1,7) 0]; % Apply vaccination rate from v_base_SIA corresponding to SIA_timing(j)
                 end
            end

            if i==3
                epsilon3=epsilon33;
            end

  if t==1
                if i==1
            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - d(i)*M(t,i)-omega22(i)*M(t,i); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - d(i)*S(t,i)-omega2(i)*S(t,i);
            dFidt(t,i) = -  F(t,i) * Lambda_all(t,i)*beta_t(t) - d(i)*F(t,i)-omega2(i)*F(t,i);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)-omega2(i)*R(t,i);
            dV1idt(t,i) = - d(i)*V1(t,i)-omega2(i)*V1(t,i);
            dV2idt(t,i) = - d(i)*V2(t,i)-omega2(i)*V2(t,i);
            dVSIAidt(t,i) = - d(i)*VSIA(t,i)-omega2(i)*VSIA(t,i);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);


                elseif i==10

            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i))*M(t,i) - d(i)*M(t,i)+omega11(i)*M(t,i-1); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)+omega1(i)*S(t,i-1);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)+omega1(i)*F(t,i-1);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)+omega1(i)*R(t,i-1);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)+omega1(i)*V1(t,i-1);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)+omega1(i)*V2(t,i-1);
            dVSIAidt(t,i) = epsilon3*v3(i)*(S(t,i) + F(t,i)) - d(i)*VSIA(t,i)+omega1(i)*VSIA(t,i-1);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);

                else
            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i))*M(t,i) - d(i)*M(t,i)+omega11(i)*M(t,i-1)-omega22(i)*M(t,i); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)+omega1(i)*S(t,i-1)-omega2(i)*S(t,i);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)+omega1(i)*F(t,i-1)-omega2(i)*F(t,i);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)+omega1(i)*R(t,i-1)-omega2(i)*R(t,i);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)+omega1(i)*V1(t,i-1)-omega2(i)*V1(t,i);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)+omega1(i)*V2(t,i-1)-omega2(i)*V2(t,i);
            dVSIAidt(t,i) = epsilon3*v3(i)*( S(t,i) + F(t,i)) - d(i)*VSIA(t,i)+omega1(i)*VSIA(t,i-1)-omega2(i)*VSIA(t,i);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);
                end
            
else

            if i==1
            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i))*M(t,i) - d(i)*M(t,i)-omega22(i)*M(t,i); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)-omega2(i)*S(t,i);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)-omega2(i)*F(t,i);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)-omega2(i)*R(t,i);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)-omega2(i)*V1(t,i);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)-omega2(i)*V2(t,i);
            dVSIAidt(t,i) = epsilon3*v3(i)*( S(t,i) + F(t,i)) - d(i)*VSIA(t,i)-omega2(i)*VSIA(t,i);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);


            elseif i==10

            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i))*M(t,i) - d(i)*M(t,i)+omega11(i)*M(t-1,i-1); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)+omega1(i)*S(t-1,i-1);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)+omega1(i)*F(t-1,i-1);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)+omega1(i)*R(t-1,i-1);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)+omega1(i)*V1(t-1,i-1);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)+omega1(i)*V2(t-1,i-1);
            dVSIAidt(t,i) = epsilon3*v3(i)*( S(t,i) + F(t,i)) - d(i)*VSIA(t,i)+omega1(i)*VSIA(t-1,i-1);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);

            else
             beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i) )*M(t,i) - d(i)*M(t,i)+omega11(i)*M(t-1,i-1)-omega22(i)*M(t,i); 
            dSidt(t,i) = double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)+omega1(i)*S(t-1,i-1)-omega2(i)*S(t,i);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)+omega1(i)*F(t-1,i-1)-omega2(i)*F(t,i);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)+omega1(i)*R(t-1,i-1)-omega2(i)*R(t,i);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)+omega1(i)*V1(t-1,i-1)-omega2(i)*V1(t,i);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)+omega1(i)*V2(t-1,i-1)-omega2(i)*V2(t,i);
            dVSIAidt(t,i) = epsilon3*v3(i)*( S(t,i) + F(t,i)) - d(i)*VSIA(t,i)+omega1(i)*VSIA(t-1,i-1)-omega2(i)*VSIA(t,i);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);
            end
  end
            
            
        end
        M(t+1,:) = M(t,:) + dt * dMidt(t,:);
        S(t+1,:) = S(t,:) + dt * dSidt(t,:);
        F(t+1,:) = F(t,:) + dt * dFidt(t,:);
        I(t+1,:) = I(t,:) + dt * dIidt(t,:);
        R(t+1,:) = R(t,:) + dt * dRidt(t,:);
        V1(t+1,:) = V1(t,:) + dt * dV1idt(t,:);
        V2(t+1,:) = V2(t,:) + dt * dV2idt(t,:);
        VSIA(t+1,:) = VSIA(t,:) + dt * dVSIAidt(t,:);
        N(t+1,:) = M(t+1,:) + S(t+1,:) + F(t+1,:) + I(t+1,:) + R(t+1,:)+V1(t+1,:)+V2(t+1,:)+VSIA(t+1,:);
        I_total(t+1) = sum(I(t+1,:));
        incidence_all_ages(t+1)=sum(incidence(t+1,:));
 end
   
    
FORCAST_LENGTH1=length(num_steps:num_steps+FY*26);
FORCAST_LENGTH=floor(FORCAST_LENGTH1/26);

    for k = 1:FORCAST_LENGTH
        I_yearly(length(I_data)+k) = sum(incidence_all_ages((k-1)*26 + 1+num_steps : (k)*26+num_steps));
    end

    Age_pop_UP_2011_total=1414203896; %2021 population
    Age_pop_UP_2011 = (1/100)*[15.8/20*ones(1,4), 15.8/5*ones(1,4), 25.5, 58.7]*Age_pop_UP_2011_total;
    
   for kk=1:n
    for k = 1:length(I_yearly)
        incidence_yearly(k,kk) = sum(incidence((k-1+add_years)*26 + 1 : (k+add_years)*26,kk));
        NN(k,kk)=N((k+add_years)*26,kk);
          % normalized_incidence_yearly(k,kk)=100000*(incidence_yearly(k,kk)/NN(k,kk));
           normalized_incidence_yearly(k,kk)=100000*(incidence_yearly(k,kk)/Age_pop_UP_2011(kk));
    end
   end    

y=[param(5)*I_yearly' param(5)*normalized_incidence_yearly NN];
