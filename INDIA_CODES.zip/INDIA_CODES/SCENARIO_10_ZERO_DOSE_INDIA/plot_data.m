clear all
clc
%% import data

cases_nigeria = [212183 168107 42007 141258 31521 110927 704 2613 9960 1272 8491 18843 6447 ...
    52852 6855 12423 17136 11190 7063 28094 8877 10649 23983 20143];

timescl = 2000:1:2023;

SIA_coverage = [47.8 42.9 10.7 1.2 99.9 99.9 68 54.3 40.8 71.2 99.9 61.1 76.1];
SIA_timing = 2005+[0, 1, 2, 2, 3, 6, 8, 8, 10, 11, 13, 13, 14];

MCV1_coverage=[ 33, 32, 30, 34, 37, 41, 44, 41, 53, 64, 56, 49, 42, 43, 44, 42, 48, ...
     54, 56, 58, 60, 60, 60, 60];
 
MCV2_coverage=[zeros(1,19), 9, 38, 38, 38, 38];

yyaxis right
b1=bar(timescl, cases_nigeria, 'r') ;
b1.FaceAlpha = 0.2;
yyaxis left
plot(timescl,MCV1_coverage,'k-','LineWidth', 1.5)
hold on
plot(timescl,MCV2_coverage,'b--','LineWidth', 1.5)
hold on
plot(SIA_timing, SIA_coverage,'ro')
H=gca;
H.LineWidth=1; %change to the desired value     