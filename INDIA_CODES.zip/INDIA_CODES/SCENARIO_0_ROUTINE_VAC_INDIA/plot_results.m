clear all
close all
clc

load curves.mat
load Phatss.mat

India	= [65150 40967 5700	5604 10430 19474 12032 17250 30168 26530 8285 3305 33634 31458 56188 44258 41144 ...
    64185 36711	55443 47147	40044 51780 38835];

I_data2 = India(end:-1:1);
I_data1(1)=mean(I_data2(1:2));I_data1(length(India))=mean(I_data2(end-1:end));

for mk=2:length(India)-1
I_data1(mk)=mean(I_data2(mk-1:mk+1));
end

data1=I_data2;
DT=1; % temporal resolution of the data in days

% create time vector in days
timevect=1:length(data1);

% number of bootstrap realizations
M=1000;
% estimate mean and 95% CI from distribution of parameter estimates
param_alpha111=[mean(Phatss(:,1)) quantile(Phatss(:,1),0.025) quantile(Phatss(:,1),0.975)];
param_alpha112=[mean(Phatss(:,2)) quantile(Phatss(:,2),0.025) quantile(Phatss(:,2),0.975)];
param_alpha113=[mean(Phatss(:,3)) quantile(Phatss(:,3),0.025) quantile(Phatss(:,3),0.975)];
param_alpha114=[mean(Phatss(:,4)) quantile(Phatss(:,4),0.025) quantile(Phatss(:,4),0.975)];
param_reporting=[mean(Phatss(:,5)) quantile(Phatss(:,5),0.025) quantile(Phatss(:,5),0.975)];

cad1=strcat('alpha_111=',num2str(param_alpha111(end,1),2),' (95% CI:',num2str(param_alpha111(end,2),2),',',num2str(param_alpha111(end,3),2),')')
cad2=strcat('alpha_112=',num2str(param_alpha112(end,1),2),' (95% CI:',num2str(param_alpha112(end,2),2),',',num2str(param_alpha112(end,3),2),')')
cad3=strcat('alpha_113=',num2str(param_alpha113(end,1),2),' (95% CI:',num2str(param_alpha113(end,2),2),',',num2str(param_alpha113(end,3),2),')')
cad4=strcat('alpha_114=',num2str(param_alpha114(end,1),2),' (95% CI:',num2str(param_alpha114(end,2),2),',',num2str(param_alpha114(end,3),2),')')
cad5=strcat('reporting=',num2str(param_reporting(end,1),2),' (95% CI:',num2str(param_reporting(end,2),2),',',num2str(param_reporting(end,3),2),')')
% plot empirical distributions of r and p
% figure(1)
% subplot(2,3,1)
% hist(Phatss(:,1))
% xlabel('alpha_111')
% ylabel('Frequency')
% 
% % title(cad1)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,2)
% hist(Phatss(:,2))
% xlabel('alpha_112')
% ylabel('Frequency')
% 
% % title(cad2)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,3)
% hist(Phatss(:,3))
% xlabel('alpha_113')
% ylabel('Frequency')
% 
% % title(cad3)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,4)
% hist(Phatss(:,4))
% xlabel('alpha_114')
% ylabel('Frequency')
% 
% % title(cad4)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,3)
% hist(Phatss(:,3))
% xlabel('alpha_113')
% ylabel('Frequency')
% 
% % title(cad3)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')
% 
% subplot(2,3,5)
% hist(Phatss(:,5))
% xlabel('reporting rate')
% ylabel('Frequency')
% 
% % title(cad4)
% 
% set(gca,'FontSize', 16);
% set(gcf,'color','white')

% plot model fit and uncertainty around model fit

% param_beta_e_time2=[];
% param_beta_h_time2=[];
% param_rho_time2=[];
% param_nu_time2=[];

%% 3) Generate short-term forecasts

close all

% forecast horizon
forecastingperiod=27; % number of data points ahead

timevect2=(1:forecastingperiod);

% vector to store forecast curves
curvesforecasts1=[]; curvesforecasts_age_specific1=[];
curvesforecasts_age_specific2=[];curvesforecasts_age_specific3=[];
curvesforecasts_age_specific4=[];curvesforecasts_age_specific5=[];
curvesforecasts_age_specific6=[];curvesforecasts_age_specific7=[];
curvesforecasts_age_specific8=[];curvesforecasts_age_specific9=[];
curvesforecasts_age_specific10=[];

% generate forecast curves from each bootstrap realization
for realization=1:M
    
%     r_hat=Phatss(realization,1);
%     p_hat=Phatss(realization,2);
    z1=Phatss(realization,:); 
%     [~,x]=ode45(@simpleGrowth,timevect2,IC,[],r_hat,p_hat,flag1);     
    
    incidence11=measles_sol1(z1, timevect, timevect2);
    incidence1=incidence11(:,1);
    
    %NNN=incidence11(:,end);
    age_specific_incidence=incidence11(:,2:end-1);
    
    curvesforecasts1=[curvesforecasts1 incidence1];
    curvesforecasts_age_specific1=[curvesforecasts_age_specific1 age_specific_incidence(:,1)];
    curvesforecasts_age_specific2=[curvesforecasts_age_specific2 age_specific_incidence(:,2)];
    curvesforecasts_age_specific3=[curvesforecasts_age_specific3 age_specific_incidence(:,3)];
    curvesforecasts_age_specific4=[curvesforecasts_age_specific4 age_specific_incidence(:,4)];
    curvesforecasts_age_specific5=[curvesforecasts_age_specific5 age_specific_incidence(:,5)];
    curvesforecasts_age_specific6=[curvesforecasts_age_specific6 age_specific_incidence(:,6)];
    curvesforecasts_age_specific7=[curvesforecasts_age_specific7 age_specific_incidence(:,7)];
    curvesforecasts_age_specific8=[curvesforecasts_age_specific8 age_specific_incidence(:,8)];
    curvesforecasts_age_specific9=[curvesforecasts_age_specific9 age_specific_incidence(:,9)];
    curvesforecasts_age_specific10=[curvesforecasts_age_specific10 age_specific_incidence(:,10)];
    
end

% plot forecast curves
% figure(2)
plot(timevect,curvesforecasts1(1:length(timevect),:),'c-')
hold on
curves_fitting = curvesforecasts1(1:length(timevect),:);
%line1=plot(timevect,mean(curves,2),'r-')
line1=plot(timevect,quantile(curves_fitting',0.5),'r-')
set(line1,'LineWidth',2)

line1=plot(timevect,quantile(curves_fitting',0.025),'r--')
set(line1,'LineWidth',2)

line1=plot(timevect,quantile(curves_fitting',0.975),'r--')
set(line1,'LineWidth',2)

line1=plot(timevect,data1,'bo')
set(line1,'LineWidth',2)

hold on

set(gca,'FontSize', 15);
set(gcf,'color','white')

grayColor = [.7 .7 .7];
plot(length(timevect):length(timevect)+length(timevect2),curvesforecasts1(length(timevect):end,:),'color',grayColor)
hold on
curves_forecast=curvesforecasts1(length(timevect):end,:);
line1=plot(length(timevect):length(timevect)+length(timevect2),quantile(curves_forecast',0.5),'r')
set(line1,'LineWidth',2)

line1=plot(length(timevect):length(timevect)+length(timevect2),quantile(curves_forecast',0.025),'r--')
set(line1,'LineWidth',2)

line1=plot(length(timevect):length(timevect)+length(timevect2),quantile(curves_forecast',0.975),'r--')
set(line1,'LineWidth',2)

xlabel('\fontsize{15} Year');
ylabel('\fontsize{15}Reported measles incidence')

% plot time series data
% line1=plot(data1,'ko')
% set(line1,'LineWidth',2)

% plot vertical line separating calibration versus forecast periods
line2=[timevect(end) 0;timevect(end) max(data1)*2];

%axis([timevect(1) timevect2(end) 0 max(data(:,2))*2])

% line1=plot(line2(:,1),line2(:,2),'k--')
% set(line1,'LineWidth',2)

set(gca,'FontSize',15)
y = ylim; % current y-axis limits
plot([24 24],[y(1) y(2)],'k--','LineWidth',2)
xlim([0 51]);
xticks(1:10:51); 
xticklabels({'2000', '2010', '2020', '2030', '2040', '2050'});

% save data with results
% save(strcat('Forecast-GGM-M-',num2str(M),'-tf-',num2str(t_window(end)),'-horizon-',num2str(forecastingperiod),'-flag-',num2str(flag1),'-dist-',num2str(dist1),'-factor-',num2str(factor1),'-w-',num2str(alpha1),'-',datafilename1(1:end-4),'.mat'),'-mat')


save('age_specific_cases1.mat','curvesforecasts_age_specific1');
save('age_specific_cases2.mat','curvesforecasts_age_specific2');
save('age_specific_cases3.mat','curvesforecasts_age_specific3');
save('age_specific_cases4.mat','curvesforecasts_age_specific4');
save('age_specific_cases5.mat','curvesforecasts_age_specific5');
save('age_specific_cases6.mat','curvesforecasts_age_specific6');
save('age_specific_cases7.mat','curvesforecasts_age_specific7');
save('age_specific_cases8.mat','curvesforecasts_age_specific8');
save('age_specific_cases9.mat','curvesforecasts_age_specific9');
save('age_specific_cases10.mat','curvesforecasts_age_specific10');
save('age_specific_cases_all.mat','curvesforecasts1');

% figure(3)
% % Data
% Age_pop_UP_2011_total=1059633675;
% %Age_pop_UP_2011 = (1/100)*[12.3/16*ones(1,4), 12.3/4*ones(1,4), 22.9, 64.9]*Age_pop_UP_2011_total;
% AGT=5;
% Age_pop_UP_2011=NNN(AGT);
% 
% y = ([mean(curvesforecasts_age_specific1(AGT,:)) mean(curvesforecasts_age_specific2(AGT,:)) mean(curvesforecasts_age_specific3(AGT,:)) mean(curvesforecasts_age_specific4(AGT,:)) mean(curvesforecasts_age_specific5(AGT,:)) mean(curvesforecasts_age_specific6(AGT,:)) mean(curvesforecasts_age_specific7(AGT,:)) mean(curvesforecasts_age_specific8(AGT,:)) mean(curvesforecasts_age_specific9(AGT,:)) mean(curvesforecasts_age_specific10(AGT,:))]./Age_pop_UP_2011_total)*1000000;          % Bar heights
% errors = ([std(curvesforecasts_age_specific1(AGT,:)) std(curvesforecasts_age_specific2(AGT,:)) std(curvesforecasts_age_specific3(AGT,:)) std(curvesforecasts_age_specific4(AGT,:)) std(curvesforecasts_age_specific5(AGT,:)) std(curvesforecasts_age_specific6(AGT,:)) std(curvesforecasts_age_specific7(AGT,:)) std(curvesforecasts_age_specific8(AGT,:)) std(curvesforecasts_age_specific9(AGT,:)) std(curvesforecasts_age_specific10(AGT,:))]./Age_pop_UP_2011_total)*1000000;     % Error values
% 
% % Create bar plot
% figure;
% b = bar(y);
% hold on;
% 
% % Add error bars
% er = errorbar(1:length(y), y, errors, 'k', 'LineStyle', 'none'); 
% 
% % Customize appearance
% er.LineWidth = 1.5;          % Thickness of the error bars
% b.FaceColor = [0.2 0.6 0.8]; % Change color of bars
% b.EdgeColor = 'none';        % Remove bar edges
% 
% % Add labels
% xlabel('Age classes');
% ylabel('Measles incidence per million');
% title('Bar Plot with Error Bars');
% 
% hold off;








%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%
% Age_pop_UP_2011_total=78937187; %1059633675;
% Age_pop_UP_2011 = (1/100)*[12.3/16*ones(1,4), 12.3/4*ones(1,4), 22.8, 64.9]*Age_pop_UP_2011_total;
% %Age_pop_UP_2011_total_S=0.2*sum(Age_pop_UP_2011(4:9));

% COMPARISON AGE SPECIFIC CASES
%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%
% 
% y = [mean(curvesforecasts_age_specific1(1,:)), mean(curvesforecasts_age_specific2(1,:)), mean(curvesforecasts_age_specific3(1,:)), mean(curvesforecasts_age_specific4(1,:)), mean(curvesforecasts_age_specific5(1,:)), mean(curvesforecasts_age_specific6(1,:)), mean(curvesforecasts_age_specific7(1,:)), mean(curvesforecasts_age_specific8(1,:)), mean(curvesforecasts_age_specific9(1,:)), mean(curvesforecasts_age_specific10(1,:))];  % Bar heights
% 
% y = [mean(curvesforecasts_age_specific1(end-2-26,:)), mean(curvesforecasts_age_specific2(end-2-26,:)), mean(curvesforecasts_age_specific3(end-2-26,:)), mean(curvesforecasts_age_specific4(end-2-26,:)), mean(curvesforecasts_age_specific5(end-2-26,:)), mean(curvesforecasts_age_specific6(end-2-26,:)), mean(curvesforecasts_age_specific7(end-2-26,:)), mean(curvesforecasts_age_specific8(end-2-26,:)), mean(curvesforecasts_age_specific9(end-2-26,:)), mean(curvesforecasts_age_specific10(end-2-26,:))];  % Bar heights
% 
% errors = [std(curvesforecasts_age_specific1(end-2-26,:)), std(curvesforecasts_age_specific2(end-2-26,:)), std(curvesforecasts_age_specific3(end-2-26,:)), std(curvesforecasts_age_specific4(end-2-26,:)), std(curvesforecasts_age_specific5(end-2-26,:)), std(curvesforecasts_age_specific6(end-2-26,:)), std(curvesforecasts_age_specific7(end-2-26,:)), std(curvesforecasts_age_specific8(end-2-26,:)), std(curvesforecasts_age_specific9(end-2-26,:)), std(curvesforecasts_age_specific10(end-2-26,:))];  % Error values
% % Data for bar plot
%  errors2 = [0, 0, 0.6*(215.11-77.17), 0.4*(215.11-77.17), (137.46-49.31), 0.4*(46.41-16.65), 0.3*(46.41-16.65), 0.3*(46.41-16.65), (13.27-3.76), (3.57-1.278)]/1.96;
% % Data for bar plot
% y1 = [0 0 0.6*215.11 0.4*215.11 137.46 0.4*46.41 0.3*46.41 0.3*46.41 13.27 3.57];
% % 
% yy1 = y1;
% 
% 
% y_combined = [y; yy1]';
% 
% % Create figure
% figure(3);
% 
% % Create the grouped bar plot
% b = bar(y_combined, 'grouped');
% hold on;
% 
% % Get the x-coordinates of the bars for both groups (y and yy1)
% x1 = b(1).XEndPoints;  % X positions for the first group (y)
% x2 = b(2).XEndPoints;  % X positions for the second group (yy1)
% 
% % Add error bars to the first set of bars (corresponding to y)
% er = errorbar(x1, y, errors, 'k', 'LineStyle', 'none');
% er.LineWidth = 1.5;  % Thickness of the error bars
% 
% % Add error bars to the second set of bars (corresponding to yy1)
% er2 = errorbar(x2, yy1, errors2, 'k', 'LineStyle', 'none');
% er2.LineWidth = 1.5;  % Thickness of the error bars
% 
% % Customize appearance of the bars
% xlabel('Age classes');
% ylabel('Measles incidence per 100,000');
% title('Bar Plot with Error Bars (on y and yy1)');
% age_classes = {'0-3 months', '3-6 months', '6-9 months', '9-12 months', '1-2 years', '2-3 years', '3-4 years', '4-5 years', '5-15 years', '15+ years'};
% 
% % Set the x-ticks at the center of each group of bars
% xticks(mean([x1; x2]));
% 
% % Assign the age class labels to the x-ticks
% xticklabels(age_classes);
% 
% % Finish plotting
% hold off;
