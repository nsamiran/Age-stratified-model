function y=measles_sol(param, timevect)

add_years=30; 
SIA_timing = add_years*26+[1, 1*26, 10*26+11*2, 11*26+4*2, 11*26+12*2, 12*26+3*2, 12*26+12*2, 13*26+6*2, ...
     17*26+2*2, 17*26+4*2, 17*26+8*2, 17*26+9*2, 17*26+12*2, 18*26+2*2, 18*26+3*2, 18*26+5*2, ...
     18*26+6*2, 18*26+7*2, 18*26+9*2, 18*26+10*2, 18*26+11*2, 18*26+12*2, 19*26+2*2];
 v_base_SIA1=[0.7, 0.9, 3.6, 1, 10.7, 3.5, 15.7, 14.4, 4.3, 4.6, 3, 3, 2.5, 0.1, 3, 0.3, 0, 3.8, 3.9, 5.4, 3.4, 27.2, 16.5]/100;
 %1:(1*26):(20*26-1);  
 % MCV1_coverage=[0.55*ones(1,add_years), 0.56, 0.57, 0.56, 0.6, 0.64, 0.68, 0.69, 0.7, 0.72, 0.78, 0.82, 0.84, 0.83, 0.83, 0.85, ...
 %     0.87, 0.88, 0.9, 0.93, 0.95, 0.89]/26;
 % MCV2_coverage=[zeros(1,add_years), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.27, 0.36, 0.51, 0.6, 0.69, 0.76, 0.8, 0.82, 0.84, 0.81
 %                 ]/26;

 % MCV1_coverage=[0.55*ones(1,add_years), 0.56, 0.57, 0.56, 0.6, 0.64, 0.68, 0.69, 0.7, 0.72, 0.78, 0.82, 0.84, 0.83, 0.83, 0.85, ...
 %     0.87, 0.88, 0.9, 0.93, 0.95, 0.89, 89]/26;

 MCV1_coverage=[zeros(1,11), 0, 0, 0, 0, 0, 0.1, .676, .897, .789, .833, .909, .85, .858, .885, .872, .826, .81, .66, .56, 0.56, 0.57, 0.56, 0.6, 0.64, 0.68, 0.69, 0.7, 0.72, 0.78, 0.82, 0.84, 0.83, 0.83, 0.85, ...
     0.87, 0.88, 0.9, 0.93, 0.95, 0.89, 0.89, 0.95, 0.93]/26;
 % MCV2_coverage=[zeros(1,add_years), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.27, 0.36, 0.51, 0.6, 0.69, 0.76, 0.8, 0.82, 0.84, 0.81, 82
 %                 ]/26;
 % MCV1_coverage=[0.55*ones(1,add_years), 0.56, 0.57, 0.56, 0.6, 0.64, 0.68, 0.69, 0.7, 0.72, 0.78, 0.82, 0.84, 0.83, 0.83, 0.85, ...
  %   0.87, 0.88, 0.9, 0.93, 0.95, 0.89, 89, 95, 93]/26;
 MCV2_coverage=[zeros(1,add_years), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.27, 0.36, 0.51, 0.6, 0.69, 0.76, 0.8, 0.82, 0.84, 0.81, 0.82, 0.90, 0.90
                 ]/26;

 % v_base_SIA1=0*[0.7, 0.9, 3.6, 1, 10.7, 3.5, 15.7, 14.4, 4.3, 4.6, 3, 3, 2.5, 0.1, 3, 0.3, 0, 3.8, 3.9, 5.4, 3.4, 27.2, 16.5]/100;
 % %1:(1*26):(20*26-1);  
 % MCV1_coverage=0*[0.55*ones(1,add_years), 0.56, 0.57, 0.56, 0.6, 0.64, 0.68, 0.69, 0.7, 0.72, 0.78, 0.82, 0.84, 0.83, 0.83, 0.85, ...
 %     0.87, 0.88, 0.9, 0.93, 0.95, 0.89]/26;
 % MCV2_coverage=0*[zeros(1,add_years), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.27, 0.36, 0.51, 0.6, 0.69, 0.76, 0.8, 0.82, 0.84, 0.81
 %                 ]/26;


% param = k0;
n = 10; % Number of age groups
T = (length(timevect)+add_years)*26; % Total time in days
dt = 1; % Time step
num_steps = T/dt;
%I_data = [370, 615, 476, 298, 1202, 1526, 803, 1349, 522, 337, 804, 465];
% alpha1 =  [param(1), param(2)*ones(1,7), param(3), param(4)];

India	= [65150	40967 5700	5604	10430	19474	12032	17250	30168	26530	8285	3305	33634	31458	56188	44258	41144	64185	36711	55443	47147	40044	51780	38835];

I_data2 = India(end:-1:1);
I_data1(1)=mean(I_data2(1:2));I_data1(length(India))=mean(I_data2(end-1:end));

for mk=2:length(India)-1
I_data1(mk)=mean(I_data2(mk-1:mk+1));
end

I_data=I_data2;
% I_data = [38835, 51780, 0, 46736, 51556, 7590, 64185, 41144, 44258, 56188, 31458, 33634, ...
%         22589, 16479, 23348, 25561, 21697, 18618, 21037, 12894, 8533, 5170, 8788];

% population in age groups
%Age_pop_UP_2011 = [1273542*ones(1,4), 5094167*ones(1,4), 50931598, 125069529];
Age_pop_UP_2011_total=557501301; %1059633675;
% Age_pop_UP_2011_total_S=0.04*557501301;
% Age_pop_UP_2011 = (1/100)*[1.7571*ones(1,7), 2.925, 22.8, 64.9]*Age_pop_UP_2011_total;
Age_pop_UP_2011 = (1/100)*[12.3/16*ones(1,4), 12.3/4*ones(1,4), 22.8, 64.9]*Age_pop_UP_2011_total;
Age_pop_UP_2011_total_S=0.2*sum(Age_pop_UP_2011(4:9));
% age specific contact matrix
%     a1 = 0.5;
%     b1 = 0.3;
%     c1 = 0.2;
% % beta_contact = [(1/(4*81))*ones(10,4) (1/(1*81))*ones(10,4) (10/81)*ones(10,1) (65/81)*ones(10,1)];%diag(a1*ones(1,n)) + diag(b1*ones(1,n-1),1) + diag(c1*ones(1,n-1),-1);
% beta_contact =diag(a1*ones(1,n)) + diag(b1*ones(1,n-1),1) + diag(c1*ones(1,n-1),-1);
% beta_contact = [(1273542/(sum(Age_pop_UP_2011)))*ones(10,4) (5094167/(sum(Age_pop_UP_2011)))*ones(10,4) (50931598/sum(Age_pop_UP_2011))*ones(10,1) (125069529/sum(Age_pop_UP_2011))*ones(10,1)];%diag(a1*ones(1,n)) + diag(b1*ones(1,n-1),1) + diag(c1*ones(1,n-1),-1);
%beta_contact = [(Age_pop_UP_2011(1)/(sum(Age_pop_UP_2011)))*ones(10,7) (Age_pop_UP_2011(8)/(sum(Age_pop_UP_2011)))*ones(10,1) (Age_pop_UP_2011(9)/sum(Age_pop_UP_2011))*ones(10,1) (Age_pop_UP_2011(10)/sum(Age_pop_UP_2011))*ones(10,1)];%diag(a1*ones(1,n)) + diag(b1*ones(1,n-1),1) + diag(c1*ones(1,n-1),-1);

% beta_contact =[0.153022 0.153022  0.153022 0.153022 0.164054 0.174704 0.172652 0.164089 0.144 0.066;
%                0.153022 0.153022  0.153022 0.153022 0.164054 0.174704 0.172652 0.164089 0.144 0.066;
%                0.153022 0.153022  0.153022 0.153022 0.164054 0.174704 0.172652 0.164089 0.144 0.066;
%                0.153022 0.153022  0.153022 0.153022 0.164054 0.174704 0.172652 0.164089 0.144 0.066;
%                0.5262 0.5262 0.5262 0.5262 0.1648 0.1757 0.1726 0.1650 0.144 0.066;
%                0.145779 0.145779 0.145779 0.145779 0.1576 0.1722 0.1741 0.1661 0.1482 0.0657;
%                0.13803 0.13803 0.13803 0.13803 0.1484 0.1668 0.2783 0.2687 0.1856 0.0652;
%                0.133063 0.133063 0.133063 0.133063 0.1439 0.1614 0.2725 0.2633 0.1831 0.0659;
%                0.1096 0.1096 0.1096 0.1096 0.1181 0.1351 0.1765 0.1716 0.8920, 0.0885;
%                0.1007 0.1007 0.1007 0.1007 0.1081 0.1211 0.1263 0.1271 0.1717 0.1378];
beta_contact=ones(10,10);
% AA=eig(beta_contact);
% Spectral1=abs(AA);
% Spectral_radius=max(Spectral1);
% param =16/(14*Spectral_radius);
% mean_beta=param(6);
alpha1=0.3686*[param(1)*ones(1,4) param(2)*ones(1,4) param(3) param(4)];
    % model parameters
    % b = [(21.8/(1000*26)), zeros(1, n-1)]; % birth rate 
     % d = (7.1/(1000*26)) * ones(1, n); % death rate

   % d = 1/(1000*26)*[4.4*ones(1,4), 4.4*ones(1,4), 1, 18.77];
%     b= [0.0001, zeros(1, n)];
%     d= 0.0001*ones(1, n);
    gamma1 = (1/1) * ones(1, n); % Recovery rates for each age class
    mu = [0.0, 0.0, 0.1667, zeros(1, n-3)]; % transfer rate from M to S
%     goat =param(2);
    alpha2 = [0.3, 0.8, 1, zeros(1, n-3)]; % modification parameter for maternally immune class
    epsilon1 = 0.95; % efficacy of MCV1
    epsilon2 = 0.98; % efficacy of MCV2
    epsilon3 = 0.7; % efficacy of SIA
    beta_2 = 0.05; % strength of seasonality
   
    %%%%%%%%% BASE SCENARIO %%%%%%%%%%%%%

    SIA_ages = [4 5 6 7 8 9]; % Age groups who receive SIA
   
    % Preallocate arrays to store results
    M = zeros(num_steps, n);
    S = zeros(num_steps, n);
    F = zeros(num_steps, n);
    I = zeros(num_steps, n);
    R = zeros(num_steps, n);
    V1 = zeros(num_steps, n);
    V2 = zeros(num_steps, n);
    VSIA = zeros(num_steps, n);
    N = zeros(num_steps, n);
    incidence=zeros(num_steps,n);

    % omega1=1*[0, (1/90)*ones(1,4), (1/26)*ones(1,4), 1/(10*26)];
    % omega2=1*[ (1/90)*ones(1,4), (1/26)*ones(1,4), 1/(10*26),0];
    % omega11=[0, (1/90)*ones(1,2), (0)*ones(1,6), 0];
    % omega22=1*[ (1/90)*ones(1,3), (0)*ones(1,5), 0,0];


    omega1=[0, (1/6)*ones(1,4), (1/26)*ones(1,4), 1/(10*26)];
    omega2=[ (1/6)*ones(1,4), (1/26)*ones(1,4), 1/(10*26),0];
    omega11=[0, (1/6)*ones(1,2), (0)*ones(1,6), 0];
    omega22=[ (1/6)*ones(1,2), (0)*ones(1,6), 0,0];

   % Initial conditions
    
    M(1,:) = [Age_pop_UP_2011(1:3), zeros(1,n-3)]; %initial maternally immune people
    S(1,:) = [0.0*Age_pop_UP_2011(1:3), (0.22).*Age_pop_UP_2011_total_S, (0.27).*Age_pop_UP_2011_total_S, ...
        (0.18).*Age_pop_UP_2011_total_S, (0.12).*Age_pop_UP_2011_total_S, (0.17).*Age_pop_UP_2011_total_S, ...
        (0.12).*Age_pop_UP_2011_total_S, (0.001).*Age_pop_UP_2011_total_S]; % Initial susceptible population in each age class
       
    % S(1,:) = [0.0*Age_pop_UP_2011(1:3), (0.22).*Age_pop_UP_2011_total_S, (0.27).*Age_pop_UP_2011_total_S, ...
    %     (0.18).*Age_pop_UP_2011_total_S, (0.12).*Age_pop_UP_2011_total_S, (0.07).*Age_pop_UP_2011_total_S, ...
    %     (0.12).*Age_pop_UP_2011_total_S, (0.001).*Age_pop_UP_2011_total_S];
    % 
    F(1,:) = [(0.0).*Age_pop_UP_2011(1:3), (0.01).*S(1,4:end)]; % initial vaccine failure
    I(1,:) = 1*ones(1,n); % Initial infected population 370 cases in 2011
    I(1,6:10)=0;
    % R(1,:) = [(0.0).*Age_pop_UP_2011(1:3), (0.69).*Age_pop_UP_2011(4:8), (1-0.2-1e-2).*Age_pop_UP_2011(9),...
%     (1-0.2-1e-2).*Age_pop_UP_2011(10)]; % Initial recovered population in each age class
    V1(1,:) = zeros(1, n); % initial mcv1
    V2(1,:) = zeros(1, n); % initial mcv2
    VSIA(1,:) = zeros(1, n); % initial SIA
    R(1,:)=Age_pop_UP_2011-M(1,:)-S(1,:)-F(1,:)-I(1,:)-V1(1,:)-V2(1,:)-VSIA(1,:);
    N(1,:) = M(1,:) + S(1,:) + F(1,:) + I(1,:) + R(1,:) + V1(1,:) + V2(1,:) + VSIA(1,:);
    I_total(1) = sum(I(1,:));
    incidence_all_ages(1)= sum(I(1,:));
    incidence(1,:) = I(1,:);
    % Simulation using Euler method
for t = 1:num_steps-1
        % Determine if vaccination is happening at this time step
        current_time = 1+(t-1) * dt;
          
        Crude_birth_rate=41- (19/40)*(floor(current_time/26));
         Crude_death_rate=19- (14/40)*(floor(current_time/26));
          b = [(Crude_birth_rate/(1000*26)), zeros(1, n-1)]; % birth rate 

          d = (Crude_death_rate/(1000*26)) * ones(1, n); % death rate
          
    for jj = 1:length(MCV1_coverage)
        if ((1+(jj-1)*26 <= current_time) && (current_time < (jj)*26))
        v1 = MCV1_coverage(jj);
        v2 = MCV2_coverage(jj);
        end
    end

    v11 = [0 0 0 v1 zeros(1,6)];
    v21 = [0 0 0 0 v2 zeros(1,5)];
        
        for i = 1:n
            % Calculate the force of infection for age group i
            lambda_1(t) = 0;
            for k = 1:n
                lambda_1(t) = lambda_1(t) + (alpha1(i)*(beta_contact(i,k)*(I(t,k))))/N(t,k);
            end
            Lambda_all(t,i) = lambda_1(t);
            
            v3 = zeros(1,n);
            for jl = 1:length(SIA_timing)  % Loop through each SIA_timing event
                 if (current_time == SIA_timing(jl))
                   v3 = [0 0 0 v_base_SIA1(jl)*ones(1,6) 0]; % Apply vaccination rate from v_base_SIA corresponding to SIA_timing(j)
                 end
            end

              if t==1
                if i==1
            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            % beta_t(t)=(1-beta_2*cos(2*pi*current_time));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - d(i)*M(t,i)-omega22(i)*M(t,i); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - d(i)*S(t,i)-omega2(i)*S(t,i);
            dFidt(t,i) = -  F(t,i) * Lambda_all(t,i)*beta_t(t) - d(i)*F(t,i)-omega2(i)*F(t,i);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)-omega2(i)*R(t,i);
            dV1idt(t,i) = - d(i)*V1(t,i)-omega2(i)*V1(t,i);
            dV2idt(t,i) = - d(i)*V2(t,i)-omega2(i)*V2(t,i);
            dVSIAidt(t,i) = - d(i)*VSIA(t,i)-omega2(i)*VSIA(t,i);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);


                elseif i==10

            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            % beta_t(t)=(1-beta_2*cos(2*pi*current_time));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i))*M(t,i) - d(i)*M(t,i)+omega11(i)*M(t,i-1); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)+omega1(i)*S(t,i-1);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)+omega1(i)*F(t,i-1);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)+omega1(i)*R(t,i-1);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)+omega1(i)*V1(t,i-1);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)+omega1(i)*V2(t,i-1);
            dVSIAidt(t,i) = epsilon3*v3(i)*(S(t,i) + F(t,i)) - d(i)*VSIA(t,i)+omega1(i)*VSIA(t,i-1);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);

                else
            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            % beta_t(t)=(1-beta_2*cos(2*pi*current_time));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i))*M(t,i) - d(i)*M(t,i)+omega11(i)*M(t,i-1)-omega22(i)*M(t,i); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)+omega1(i)*S(t,i-1)-omega2(i)*S(t,i);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)+omega1(i)*F(t,i-1)-omega2(i)*F(t,i);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)+omega1(i)*R(t,i-1)-omega2(i)*R(t,i);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)+omega1(i)*V1(t,i-1)-omega2(i)*V1(t,i);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)+omega1(i)*V2(t,i-1)-omega2(i)*V2(t,i);
            dVSIAidt(t,i) = epsilon3*v3(i)*( S(t,i) + F(t,i)) - d(i)*VSIA(t,i)+omega1(i)*VSIA(t,i-1)-omega2(i)*VSIA(t,i);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);
                end
            
else

            if i==1
            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            % beta_t(t)=(1-beta_2*cos(2*pi*current_time));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i))*M(t,i) - d(i)*M(t,i)-omega22(i)*M(t,i); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)-omega2(i)*S(t,i);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)-omega2(i)*F(t,i);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)-omega2(i)*R(t,i);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)-omega2(i)*V1(t,i);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)-omega2(i)*V2(t,i);
            dVSIAidt(t,i) = epsilon3*v3(i)*( S(t,i) + F(t,i)) - d(i)*VSIA(t,i)-omega2(i)*VSIA(t,i);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);


            elseif i==10

            beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            % beta_t(t)=(1-beta_2*cos(2*pi*current_time));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i))*M(t,i) - d(i)*M(t,i)+omega11(i)*M(t-1,i-1); 
            dSidt(t,i) =  double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)+omega1(i)*S(t-1,i-1);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)+omega1(i)*F(t-1,i-1);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)+omega1(i)*R(t-1,i-1);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)+omega1(i)*V1(t-1,i-1);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)+omega1(i)*V2(t-1,i-1);
            dVSIAidt(t,i) = epsilon3*v3(i)*( S(t,i) + F(t,i)) - d(i)*VSIA(t,i)+omega1(i)*VSIA(t-1,i-1);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);

            else
             beta_t(t)=(1-beta_2*cos(2*pi*current_time/26));
            % beta_t(t)=(1-beta_2*cos(2*pi*current_time));
            dMidt(t,i) = b(i)*sum(N(t,:)) - alpha2(i)*M(t,i)*Lambda_all(t,i)*beta_t(t) - mu(i)*M(t,i) - (v11(i) )*M(t,i) - d(i)*M(t,i)+omega11(i)*M(t-1,i-1)-omega22(i)*M(t,i); 
            dSidt(t,i) = double(ismember(i, 4))*mu(3)*M(t,3) -  S(t,i) *Lambda_all(t,i)*beta_t(t)  - (v11(i) + epsilon3*v3(i))*S(t,i) - d(i)*S(t,i)+omega1(i)*S(t-1,i-1)-omega2(i)*S(t,i);
            dFidt(t,i) = (1-epsilon1)*v11(i)*(S(t,i) + M(t,i)) -  F(t,i) * Lambda_all(t,i)*beta_t(t) - (epsilon2*v21(i) + epsilon3*v3(i))*F(t,i) - d(i)*F(t,i)+omega1(i)*F(t-1,i-1)-omega2(i)*F(t,i);
            dIidt(t,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t) - gamma1(i)*I(t,i) - d(i)*I(t,i);
            dRidt(t,i) = gamma1(i)*I(t,i) - d(i)*R(t,i)+omega1(i)*R(t-1,i-1)-omega2(i)*R(t,i);
            dV1idt(t,i) = epsilon1*v11(i)*(S(t,i) + M(t,i)) - d(i)*V1(t,i)+omega1(i)*V1(t-1,i-1)-omega2(i)*V1(t,i);
            dV2idt(t,i) = epsilon2*v21(i)*F(t,i) - d(i)*V2(t,i)+omega1(i)*V2(t-1,i-1)-omega2(i)*V2(t,i);
            dVSIAidt(t,i) = epsilon3*v3(i)*( S(t,i) + F(t,i)) - d(i)*VSIA(t,i)+omega1(i)*VSIA(t-1,i-1)-omega2(i)*VSIA(t,i);
            incidence(t+1,i) = (alpha2(i)*M(t,i) + S(t,i) + F(t,i))*Lambda_all(t,i)*beta_t(t);
            end
             end
            
            
        end

        M(t+1,:) = M(t,:) + dt * dMidt(t,:);
        S(t+1,:) = S(t,:) + dt * dSidt(t,:);
        F(t+1,:) = F(t,:) + dt * dFidt(t,:);
        I(t+1,:) = I(t,:) + dt * dIidt(t,:);
        R(t+1,:) = R(t,:) + dt * dRidt(t,:);
        V1(t+1,:) = V1(t,:) + dt * dV1idt(t,:);
        V2(t+1,:) = V2(t,:) + dt * dV2idt(t,:);
        VSIA(t+1,:) = VSIA(t,:) + dt * dVSIAidt(t,:);
        %incidence(t+1,:)=incidence(t,:) ;%+ dt*incidence(t,:);
        N(t+1,:) = M(t+1,:) + S(t+1,:) + F(t+1,:) + I(t+1,:) + R(t+1,:)+V1(t+1,:)+V2(t+1,:)+VSIA(t+1,:);
        I_total(t+1) = sum(I(t+1,:));
        incidence_all_ages(t+1)=sum(incidence(t+1,:));
end
   
    

% plot(incidence_all_ages_yearly1,'b','LineWidth',2);hold on

I_yearly = zeros(1, length(I_data));
    for k = 1:length(I_data)
        I_yearly(k) = sum(incidence_all_ages((k-1+add_years)*26 + 1 : (k+add_years)*26));
    end

y=param(5)*I_yearly;
