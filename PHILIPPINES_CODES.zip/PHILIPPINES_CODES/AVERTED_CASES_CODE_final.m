clc
clear all
close all

% Load data and calculate the mean and standard deviation for each scenario
filePath111 = load(fullfile('ROUTINE_VAC_SCENARIO_1_PHILIPPINES', 'age_specific_cases_all.mat'));
filePath211 = load(fullfile('EARLY_VAC_SCENARIO_1_PHILIPPINES', 'age_specific_cases_all.mat'));
filePath311 = load(fullfile('ZERO_DOSE_SCENARIO_1_DRC', 'age_specific_cases_all.mat'));

var111 = filePath111.curvesforecasts1(25:end, :);
var112 = filePath211.curvesforecasts1(25:end, :);
var113 = filePath311.curvesforecasts1(25:end, :);

avar111 = sum(var111, 1);
avar112 = sum(var112, 1);
avar113 = sum(var113, 1);

averted_1 = (avar111 - avar112);
averted_1EARLY = (avar111 - avar113);

mean_averted_1 = mean(averted_1);
std_averted_1 = std(averted_1);
mean_averted_1EARLY = mean(averted_1EARLY);
std_averted_1EARLY = std(averted_1EARLY);

% Repeat the process for scenarios 2, 3, and 4
filePath111 = load(fullfile('ROUTINE_VAC_SCENARIO_2_PHILIPPINES', 'age_specific_cases_all.mat'));
filePath211 = load(fullfile('EARLY_VAC_SCENARIO_2_PHILIPPINES', 'age_specific_cases_all.mat'));
filePath311 = load(fullfile('ZERO_DOSE_SCENARIO_2_DRC', 'age_specific_cases_all.mat'));

var111 = filePath111.curvesforecasts1(25:end, :);
var112 = filePath211.curvesforecasts1(25:end, :);
var113 = filePath311.curvesforecasts1(25:end, :);

avar111 = sum(var111, 1);
avar112 = sum(var112, 1);
avar113 = sum(var113, 1);

averted_2 = (avar111 - avar112);
averted_2EARLY = (avar111 - avar113);

mean_averted_2 = mean(averted_2);
std_averted_2 = std(averted_2);
mean_averted_2EARLY = mean(averted_2EARLY);
std_averted_2EARLY = std(averted_2EARLY);

% Calculate for scenario 3
filePath111 = load(fullfile('ROUTINE_VAC_SCENARIO_3_PHILIPPINES', 'age_specific_cases_all.mat'));
filePath211 = load(fullfile('EARLY_VAC_SCENARIO_3_PHILIPPINES', 'age_specific_cases_all.mat'));
filePath311 = load(fullfile('ZERO_DOSE_SCENARIO_3_DRC', 'age_specific_cases_all.mat'));

var111 = filePath111.curvesforecasts1(25:end, :);
var112 = filePath211.curvesforecasts1(25:end, :);
var113 = filePath311.curvesforecasts1(25:end, :);

avar111 = sum(var111, 1);
avar112 = sum(var112, 1);
avar113 = sum(var113, 1);

averted_3 = (avar111 - avar112);
averted_3EARLY = (avar111 - avar113);

mean_averted_3 = mean(averted_3);
std_averted_3 = std(averted_3);
mean_averted_3EARLY = mean(averted_3EARLY);
std_averted_3EARLY = std(averted_3EARLY);

% Calculate for scenario 4
filePath111 = load(fullfile('ROUTINE_VAC_SCENARIO_4_PHILIPPINES', 'age_specific_cases_all.mat'));
filePath211 = load(fullfile('EARLY_VAC_SCENARIO_4_PHILIPPINES', 'age_specific_cases_all.mat'));
filePath311 = load(fullfile('ZERO_DOSE_SCENARIO_4_DRC', 'age_specific_cases_all.mat'));

var111 = filePath111.curvesforecasts1(25:end, :);
var112 = filePath211.curvesforecasts1(25:end, :);
var113 = filePath311.curvesforecasts1(25:end, :);

avar111 = sum(var111, 1);
avar112 = sum(var112, 1);
avar113 = sum(var113, 1);

averted_4 = (avar111 - avar112);
averted_4EARLY = (avar111 - avar113);

mean_averted_4 = mean(averted_4);
std_averted_4 = std(averted_4);
mean_averted_4EARLY = mean(averted_4EARLY);
std_averted_4EARLY = std(averted_4EARLY);

% Combine results for plotting
mean_averted = [mean_averted_1, mean_averted_4, mean_averted_3, mean_averted_2, ...
                mean_averted_1EARLY, mean_averted_4EARLY, mean_averted_3EARLY, mean_averted_2EARLY];
std_averted = [std_averted_1, std_averted_4, std_averted_3, std_averted_2, ...
               std_averted_1EARLY, std_averted_4EARLY, std_averted_3EARLY, std_averted_2EARLY];

% Define distinct base colors for each bar group
color1 = [0.2, 0.6, 0.8]; % Base color for Routine Vaccination
color2 = [0.8, 0.4, 0.2]; % Base color for Early Vaccination

% Create distinct colors for the 4 bars in each group
colors_group1 = [
    color1;                       % First bar
    color1 * 0.8;                 % Slightly darker
    color1 * 0.6;                 % Even darker
    color1 * 0.4                  % Deepest color
];

colors_group2 = [
    color2;                       % First bar
    color2 * 0.8;                 % Slightly darker
    color2 * 0.6;                 % Even darker
    color2 * 0.4                  % Deepest color
];

% Combine colors for all bars
bar_colors = [colors_group1; colors_group2];

% Plot the bar graph
figure;
for i = 1:length(mean_averted)
    bar(i, mean_averted(i), 'FaceColor', bar_colors(i, :), 'EdgeColor', 'k', 'LineWidth', 1.2); % Individual bar plot
    hold on;
end

% Add error bars
errorbar(1:length(mean_averted), mean_averted, std_averted, 'k.', 'LineWidth', 1.5);

% Customize the plot
xlabel('Scenario', 'FontSize', 12);
ylabel('Total averted cases', 'FontSize', 12);
title('Philippines', 'FontSize', 15);
set(gca, 'XTick', []); % Removes x-tick marks and labels
grid on;
set(gca, 'FontSize', 12);


% Add legend
%legend({'Routine Vaccination', 'Early Vaccination'}, 'Location', 'northwest', 'FontSize', 10);

% Improve overall aesthetics
box on;
axis tight;
%ylim([0 12.5*10^5]);